"""
BOMA — BOM Analysis Agent (v3.0.0)
Dual-mode: Joule Studio (JOULE_RUNTIME=1) or Cloud Foundry AI Core (JOULE_RUNTIME=0)
"""
from __future__ import annotations

import logging
import os
import time
import urllib.request
import json as _json
from dataclasses import dataclass
from typing import AsyncGenerator, Literal, Sequence

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.tools import BaseTool
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.prebuilt import create_react_agent

logger = logging.getLogger(__name__)

_JOULE       = os.environ.get("JOULE_RUNTIME", "0") == "1"
_IBD_TESTING = os.environ.get("IBD_TESTING",   "0") == "1"
THREAD_TTL_SECONDS = 3600

# ─────────────────────────────────────────────────────────────────────────────
# Live FX rates — fetched from open.er-api.com (free, no key needed)
# Cached 30 min so every agent response uses fresh market rates
# ─────────────────────────────────────────────────────────────────────────────
_fx_cache: dict = {}
_fx_cache_time: float = 0.0
_FX_TTL = 1800


def get_live_fx_rates() -> dict:
    global _fx_cache, _fx_cache_time
    now = time.monotonic()
    if _fx_cache and (now - _fx_cache_time) < _FX_TTL:
        return _fx_cache
    try:
        url = "https://open.er-api.com/v6/latest/USD"
        r = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(r, timeout=6) as resp:
            data = _json.loads(resp.read())
        rates = data.get("rates", {})
        if not rates:
            raise ValueError("empty rates")
        usd_inr = float(rates.get("INR", 96.35))
        usd_eur = float(rates.get("EUR", 0.873))
        usd_gbp = float(rates.get("GBP", 0.741))
        usd_jpy = float(rates.get("JPY", 149.5))
        usd_chf = float(rates.get("CHF", 0.893))
        _fx_cache = {
            "USD_INR": round(usd_inr, 4),
            "EUR_INR": round(usd_inr / usd_eur, 4),
            "EUR_USD": round(1 / usd_eur, 4),
            "GBP_INR": round(usd_inr / usd_gbp, 4),
            "GBP_USD": round(1 / usd_gbp, 4),
            "JPY_INR": round(usd_inr / usd_jpy, 6),
            "CHF_INR": round(usd_inr / usd_chf, 4),
            "CHF_USD": round(1 / usd_chf, 4),
            "INR_USD": round(1 / usd_inr, 8),
            "INR_EUR": round(usd_eur / usd_inr, 8),
            "_source": "open.er-api.com",
            "_as_of": data.get("time_last_update_utc", "live"),
        }
        _fx_cache_time = now
        logger.info("FX refreshed: 1 USD = %.4f INR", usd_inr)
    except Exception as exc:
        logger.warning("FX fetch failed: %s — using fallback", exc)
        if not _fx_cache:
            _fx_cache = {
                "USD_INR": 96.35, "EUR_INR": 110.37, "EUR_USD": 1.145,
                "GBP_INR": 130.0, "GBP_USD": 1.35, "JPY_INR": 0.645,
                "CHF_INR": 108.0, "CHF_USD": 1.12,
                "INR_USD": 0.01038, "INR_EUR": 0.00906,
                "_source": "fallback", "_as_of": "offline",
            }
    return _fx_cache


def get_system_prompt() -> str:
    """Build system prompt with live FX rates embedded. Called fresh on every agent turn."""
    fx = get_live_fx_rates()
    return f"""# BOMA — BOM & Operations Master Agent

## IDENTITY
You are **BOMA** (BOM & Operations Master Agent). NOT ARIA. NOT any other agent.
- Connected LIVE to SAP S/4HANA **CIN_100** (ABC Automotive — India's 2nd-largest vehicle maker)
- If asked your name: "I am BOMA — SAP BOM & Operations Master Agent. I autonomously analyse Bills of Materials, costs, procurement and all SAP modules."

## YOU ARE AN AGENTIC AI — NOT A CHATBOT
This is the most important rule. You do NOT ask the user for information you can fetch yourself.

**AUTONOMOUS DECISION FRAMEWORK:**
1. User gives you a material → you call `list_material_plants` to discover all plants autonomously
2. User asks for cost comparison → you fetch valuations for ALL discovered plants, compare, decide
3. User asks for FX conversion → you call `get_tcurr_fx_rate` from SAP TCURR — never use hardcoded rates
4. User asks how many materials → you call `get_material_count` immediately
5. User asks "which plant is best" → you find plants, get prices, convert to INR, rank and recommend — ALL without asking

**FORBIDDEN BEHAVIOURS (you are an agent, not a chatbot):**
- ❌ NEVER say "Please provide the plant codes" — find them yourself with `list_material_plants`
- ❌ NEVER say "I don't have a tool to count materials" — use `get_material_count`
- ❌ NEVER say "Please specify which plants" — discover them autonomously
- ❌ NEVER use plant codes MANE or GURG — this system uses numeric codes (1010, 1710, 1720, etc.)
- ❌ NEVER hallucinate plant codes — only use what `list_material_plants` returns
- ❌ NEVER use hardcoded FX rates — always call `get_tcurr_fx_rate` first
- ❌ NEVER ask the user for something they already said in the conversation

## MANDATORY TOOL EXECUTION PATTERNS

### Pattern 0: "What is the BOM number for material X?" / "BOM numbers across plants"
```
Step 1 → get_bom_headers(X)                    # NO plant = returns BOMs for ALL plants
Step 2 → Present table: Material | Plant | BOM Number | Category | Variant | Usage
Step 3 → If user asks for components → get_bom_explosion(X, plant)
```
NEVER say "I don't have a tool for BOM numbers" — get_bom_headers IS that tool.
NEVER say "use CS03 in SAP" as the answer — fetch and show the data directly.

### Pattern 1: "Which plant is best for material X?"
```
Step 1 → list_material_plants(X)            # discover all plants
Step 2 → get_material_valuation(X, plant_1) # price + currency for each plant
Step 3 → get_material_valuation(X, plant_2) # repeat for all plants found
Step 4 → get_tcurr_fx_rate(currency, INR)   # SAP TCURR rate for each currency
Step 5 → Convert all to INR, rank, recommend cheapest
Step 6 → get_material_procurement_type + get_purchase_info_records for top 2
Step 7 → Classify: Make / Buy / Strategic Buy
Step 8 → Present full analysis table
```

### Pattern 2: "How many materials are in CIN_100?"
```
Step 1 → get_material_count()               # call immediately, no questions
Step 2 → Present: "There are X materials in SAP CIN_100"
```

### Pattern 3: "Cost variance between plant A and plant B for material X"
```
Step 1 → get_material_valuation(X, A) + get_material_valuation(X, B)  # parallel
Step 2 → get_tcurr_fx_rate(currency_A, INR) + get_tcurr_fx_rate(currency_B, INR)
Step 3 → Calculate variance, classify, show table
```

### Pattern 4: Any FX conversion
```
Step 1 → get_tcurr_fx_rate(from, to)        # SAP TCURR is authoritative
         If not found → tries indirect via USD automatically
         If SAP unavailable → falls back to open.er-api.com
Step 2 → Use ONLY the rate returned by this tool. Never use memory/training rates.
```

## FX RATE RULES
- **PRIMARY**: Always call `get_tcurr_fx_rate` — SAP TCURR table is the authoritative source
- **FALLBACK** (only if tool fails): {fx['_source']} rates as of {fx['_as_of']}:
  - 1 USD = {fx['USD_INR']} INR | 1 EUR = {fx['EUR_INR']} INR | 1 GBP = {fx['GBP_INR']} INR
- ❌ FORBIDDEN hardcoded rates: USD→INR=83.3, EUR→INR=89.9 or 90.0, EUR→USD=1.08

## MAKE / BUY / STRATEGIC BUY CLASSIFICATION
After cost analysis, always classify:
- 🏭 **MAKE**: Procurement=E (in-house) OR variance < 5%
- 🛒 **BUY**: Variance ≥ 5%, multiple suppliers, external procurement possible
- ⚠️ **STRATEGIC BUY**: Variance ≥ 20% + single supplier → address sourcing risk urgently
- 📊 **HYBRID**: Procurement=X → analyse capacity + cost + volume split

Supplier risk: 1 vendor=⚠️ HIGH RISK | 2-3=moderate | 4+=competitive

## OUTPUT FORMAT — ALWAYS USE TABLES
Every cost analysis must show:

| Plant | Original Price | Currency | INR Equivalent | Variance % | Decision |
|-------|---------------|----------|----------------|------------|----------|
| 1010  | 42.0          | EUR      | XXXX INR       | —          | —        |
| 1710  | 42.0          | USD      | XXXX INR       | X.XX%      | 🛒 BUY   |

Always end with: 📋 **T-codes**: [relevant SAP transaction codes]

## HONEST FAILURE PROTOCOL
If a tool returns an error or no data, say:
"I called [tool_name] in SAP CIN_100 and received: [actual error]. This may mean:
1. Material [X] has no BOM at plant [Y] — it may be externally procured
2. The SAP service [name] is not available for this query
Please verify in SAP using [relevant T-code]."

NEVER hallucinate BOM numbers. NEVER say "00000052" unless the tool returned it.
NEVER say "I don't have access" when a tool exists — call the tool first.

## CAPABILITIES (1000+ SAP BOM Actions)
BOM: CS03 display · CS11 single-level explosion · CS12 multi-level · CS15 where-used · CS20 mass change
Cost: CK11N estimate · CK40N costing run · MR21 price change · CKMLCP actual costing
Procurement: ME11/ME13 info records · ME2M PO history · ME57 requisitions · ME59 auto-PO
Valuation: MM03 master · MB52 stock · MR11 GR/IR · MIRO invoice
Production: PP01 work centers · CA01 routings · CO01/CO02 production orders
FI/CO: FB60 vendor invoice · F110 payment run · KSB1 cost center · KE30 profitability
Quality: QA01 inspection · QM11 results · QA32 usage decisions
All modules: MM · SD · FI · CO · PP · WM/EWM · QM · PM · PS · SCM · HR · PS"""


# ─────────────────────────────────────────────────────────────────────────────
# Decorator shim (Joule vs CF)
# ─────────────────────────────────────────────────────────────────────────────
try:
    from sap_cloud_sdk.agent_decorators import agent_model, agent_config, prompt_section  # type: ignore
except ImportError:
    def _noop(*_a, **_k):
        def _w(fn): return fn
        return _w
    agent_model = agent_config = prompt_section = _noop  # type: ignore

# ─────────────────────────────────────────────────────────────────────────────
# S4 client
# ─────────────────────────────────────────────────────────────────────────────
if not _JOULE and not _IBD_TESTING:
    try:
        from s4hana_client import Client as S4Client  # type: ignore
    except ImportError:
        S4Client = None  # type: ignore
else:
    S4Client = None  # type: ignore


def get_model_name() -> str:
    return os.environ.get("AGENT_LLM_MODEL", "gpt-4o")


# ─────────────────────────────────────────────────────────────────────────────
# AgentResponse
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class AgentResponse:
    status: Literal["input_required", "completed", "error"]
    message: str


# ─────────────────────────────────────────────────────────────────────────────
# SampleAgent
# ─────────────────────────────────────────────────────────────────────────────
class SampleAgent:
    SUPPORTED_CONTENT_TYPES = ["text", "text/plain"]

    def __init__(self, s4_client=None):
        self._llm: BaseChatModel | None = None
        self._checkpointer = InMemorySaver()
        self._graph = None          # built once, reused across all turns
        self._last_active: dict[str, float] = {}
        self._s4_client = s4_client if s4_client is not None else (
            S4Client() if S4Client is not None else None
        )

    @property
    def s4_client(self):
        return self._s4_client

    # ── LLM (lazy, built once) ────────────────────────────────────────────────
    async def _get_llm(self) -> BaseChatModel | None:
        if self._llm is not None:
            return self._llm

        if _IBD_TESTING:
            try:
                from langchain_openai import ChatOpenAI  # type: ignore
                self._llm = ChatOpenAI(model="gpt-4o-mini", api_key="test-key", base_url="http://localhost:9999/")
                return self._llm
            except ImportError:
                pass
            try:
                from langchain_community.chat_models.fake import FakeMessagesListChatModel  # type: ignore
                from langchain_core.messages import AIMessage
                self._llm = FakeMessagesListChatModel(responses=[AIMessage(content="Mock response")])
                return self._llm
            except ImportError:
                pass
            return None

        if _JOULE:
            try:
                from langchain_litellm import ChatLiteLLM  # type: ignore
                self._llm = ChatLiteLLM(model="sap/anthropic--claude-4.5-sonnet", temperature=0.0)
            except ImportError as exc:
                logger.warning("Joule LLM unavailable: %s", exc)
            return self._llm

        try:
            from aicore import init_llm_from_destination  # type: ignore
            self._llm = await init_llm_from_destination(get_model_name(), temperature=0.0)
        except Exception as exc:
            logger.warning("init_llm_from_destination failed: %s", exc)
            try:
                from aicore import build_aicore_llm  # type: ignore
                self._llm = build_aicore_llm(
                    model=os.environ.get("AICORE_MODEL", get_model_name()), temperature=0.0
                )
            except Exception as exc2:
                logger.warning("build_aicore_llm also failed: %s", exc2)
        return self._llm

    # ── Graph (built once per agent instance, reused for all threads) ─────────
    async def _get_graph(self, tools: Sequence[BaseTool]):
        """
        Build graph once and cache it. The pre_model_hook fetches a fresh
        system prompt (with live FX) before every LLM call, so rates are always current.
        """
        if self._graph is not None:
            return self._graph

        llm = await self._get_llm()
        if llm is None:
            return None

        tool_list = list(tools) if tools else []

        def _pre_model_hook(state: dict) -> dict:
            """
            Fires immediately before every LLM call.
            Replaces/prepends SystemMessage with fresh BOMA identity + live FX.
            This cannot be overridden by base-model fine-tuning.
            """
            fresh_prompt = get_system_prompt()
            messages = list(state.get("messages", []))
            # Drop any existing SystemMessage at position 0
            if messages and isinstance(messages[0], SystemMessage):
                messages = messages[1:]
            return {"messages": [SystemMessage(content=fresh_prompt)] + messages}

        self._graph = create_react_agent(
            llm,
            tools=tool_list,
            pre_model_hook=_pre_model_hook,
            checkpointer=self._checkpointer,
        )
        logger.info("BOMA graph built with %d tools", len(tool_list))
        return self._graph

    # ── Thread TTL cleanup ────────────────────────────────────────────────────
    def _touch(self, thread_id: str) -> None:
        now = time.monotonic()
        expired = [tid for tid, ts in list(self._last_active.items()) if now - ts > THREAD_TTL_SECONDS]
        for tid in expired:
            try:
                self._checkpointer.delete_thread(tid)
            except Exception:
                pass
            del self._last_active[tid]
            logger.info("Evicted thread: %s", tid)
        self._last_active[thread_id] = now

    def _wrap_query(self, query: str) -> str:
        """
        Wrap every user query with BOMA agentic rules.
        Injected into the HUMAN turn — takes effect even when AI Core overrides system message.
        """
        import re as _re
        fx = get_live_fx_rates()

        # Extract [SAP SCOPE] block if present (added by React UI)
        scope_block = ""
        clean_query = query
        scope_match = _re.search(r'\[SAP SCOPE\](.*?)\n', query, _re.DOTALL)
        if scope_match:
            scope_block = scope_match.group(1).strip()
            clean_query = query[scope_match.end():].strip()

        # Build explicit plant/material instruction from UI scope
        scope_instruction = ""
        if scope_block:
            mat_match = _re.search(r'Materials in scope:\s*([^\|]+)', scope_block)
            plt_match = _re.search(r'Plants in scope:\s*([^\|]+)', scope_block)
            mats = mat_match.group(1).strip() if mat_match else ""
            plts = plt_match.group(1).strip() if plt_match else ""
            if plts:
                scope_instruction = f"\n⚠️ Plants specified by user: {plts} — use ONLY these plants, do NOT use MANE/GURG."
            if mats:
                scope_instruction += f"\n⚠️ Materials specified by user: {mats}"

        # Extract plants and materials from the question itself
        plant_codes = _re.findall(r'\b(1\d{{3}}|2\d{{3}}|3\d{{3}})\b', clean_query)
        mentioned_plants = f"Plants mentioned: {', '.join(set(plant_codes))}" if plant_codes else ""

        return f"""[BOMA AGENT RULES — EXECUTE BEFORE RESPONDING]
You are BOMA (NOT ARIA). Act as an AUTONOMOUS AGENT:

RULE 1 — IDENTITY: You are BOMA. Say "I am BOMA — SAP BOM & Operations Master Agent"
RULE 2 — FX: Call get_tcurr_fx_rate FIRST. Fallback only: 1 USD={fx['USD_INR']} INR, 1 EUR={fx['EUR_INR']} INR
RULE 3 — PLANTS: NEVER use MANE or GURG. If no plants given → call list_material_plants to discover them
RULE 4 — COUNT: If asked "how many materials" → call get_material_count immediately
RULE 5 — NO ASKING: Do NOT ask user for info you can fetch. You are an agent. Act autonomously.
RULE 6 — CONTEXT: Material/plants already mentioned in conversation → use them, never ask again
{mentioned_plants}{scope_instruction}
[END RULES]

USER REQUEST: {clean_query}"""

    # ── stream ────────────────────────────────────────────────────────────────
    async def stream(
        self,
        query: str,
        context_id: str,
        tools: Sequence[BaseTool] | None = None,
    ) -> AsyncGenerator[dict, None]:
        self._touch(context_id)
        yield {"is_task_complete": False, "require_user_input": False, "content": "Analysing..."}

        try:
            graph = await self._get_graph(tools or [])
            if graph is None:
                yield {"is_task_complete": True, "require_user_input": False,
                       "content": "LLM not configured. Check AI Core / Joule settings."}
                return

            config = {"configurable": {"thread_id": context_id}}
            wrapped = self._wrap_query(query)
            result = await graph.ainvoke({"messages": [HumanMessage(content=wrapped)]}, config)
            self._touch(context_id)

            yield {"is_task_complete": True, "require_user_input": False,
                   "content": result["messages"][-1].content}

        except Exception as e:
            logger.exception("BOMA stream() error")
            yield {"is_task_complete": True, "require_user_input": False,
                   "content": f"Error processing request: {e}. Please try again."}

    # ── invoke (convenience wrapper) ──────────────────────────────────────────
    async def invoke(
        self,
        query: str,
        context_id: str,
        tools: Sequence[BaseTool] | None = None,
    ) -> AgentResponse:
        last: dict = {}
        async for chunk in self.stream(query, context_id, tools=tools):
            last = chunk
        if last.get("is_task_complete"):
            return AgentResponse(status="completed", message=last["content"])
        if last.get("require_user_input"):
            return AgentResponse(status="input_required", message=last["content"])
        return AgentResponse(status="error", message=last.get("content", "Unknown error"))
