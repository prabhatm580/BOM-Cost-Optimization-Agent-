import subprocess

result = subprocess.run(
    ['/tmp/cf', 'oauth-token'],
    capture_output=True, text=True,
    env={'CF_HOME': '/tmp/cfhome', 'HOME': '/tmp/cfhome', 'PATH': '/usr/bin:/bin:/tmp'}
)
token_line = result.stdout.strip()
print("Raw token line:", token_line[:120])

# Save full token line
with open('/tmp/cf_token.txt', 'w') as f:
    f.write(token_line)
print("Saved to /tmp/cf_token.txt")
