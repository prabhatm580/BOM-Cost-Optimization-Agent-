"""
A2A server entry point — dual-mode (Joule Studio + Cloud Foundry).
Also exposes:
  POST /api/analyse  — structured BOM + valuation + procurement data from S/4HANA
  POST /api/chat     — conversational agent with context/thread support
"""
from __future__ import annotations

import json as _json
import logging
import os
import uuid

_JOULE = os.environ.get("JOULE_RUNTIME", "0") == "1"

if _JOULE:
    try:
        from sap_cloud_sdk.aicore import set_aicore_config       # type: ignore
        from sap_cloud_sdk.core.telemetry import auto_instrument  # type: ignore
        set_aicore_config()
        auto_instrument()
    except ImportError:
        pass

import uvicorn
from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import AgentCapabilities, AgentCard, AgentSkill
from starlette.applications import Starlette
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.cors import CORSMiddleware
from starlette.requests import Request
from starlette.responses import FileResponse, JSONResponse, Response
from starlette.routing import Mount, Route
from starlette.staticfiles import StaticFiles

from agent_executor import AgentExecutor
from agent import get_live_fx_rates
from tools import (
    classify_make_buy,
    get_bom_cross_plant,
    get_material_procurement_type,
    get_material_valuation,
    get_purchase_info_records,
    get_purchase_order_history,
    record_feedback,
    get_feedback_summary,
)

if _JOULE:
    try:
        from mcp_tools import set_user_token  # type: ignore
    except ImportError:
        def set_user_token(tok): pass
else:
    def set_user_token(tok): pass

try:
    from opentelemetry.instrumentation.starlette import StarletteInstrumentor
    _OTEL = True
except ImportError:
    _OTEL = False

logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"))
logger = logging.getLogger(__name__)

HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", "5000"))

# ── Singleton executor (reuse S4Client across requests) ──────────────────────
_executor: AgentExecutor | None = None


def get_executor() -> AgentExecutor:
    global _executor
    if _executor is None:
        _executor = AgentExecutor()
    return _executor


# ── Middleware ────────────────────────────────────────────────────────────────
class JWTContextMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        auth = request.headers.get("authorization", "")
        tok = auth[7:].strip() if auth.lower().startswith("bearer ") else None
        set_user_token(tok or None)
        try:
            return await call_next(request)
        finally:
            set_user_token(None)


# ═══════════════════════════════════════════════════════════════════════════════
#  /api/analyse  — fetch real S/4HANA data for materials × plants
# ═══════════════════════════════════════════════════════════════════════════════
async def api_analyse(request: Request) -> JSONResponse:
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "Invalid JSON"}, status_code=400)

    materials: list[str] = body.get("materials", [])
    plants: list[str]    = body.get("plants", [])

    if not materials or len(plants) < 2:
        return JSONResponse({"error": "Need ≥1 material and ≥2 plants"}, status_code=400)

    exc = get_executor()
    s4  = exc.agent.s4_client
    out = {}

    for mat in materials:
        mat_result: dict = {"material": mat, "plants": {}, "found": False}

        # ── per-plant: procurement type + valuation ──────────────────────────
        any_found = False
        for plant in plants:
            pdata: dict = {}

            try:
                raw = await get_material_procurement_type(mat, plant, s4=s4)
                p = _json.loads(raw)
                if p.get("error") == "not_found":
                    pdata["invalid"] = True
                    pdata["invalidReason"] = p.get("message", f"Material '{mat}' not found in plant {plant}")
                elif not p.get("error"):
                    pdata["procurementType"]     = p.get("procurementType", "")
                    pdata["procurementTypeName"] = p.get("procurementTypeName", "")
                    pdata["mrpType"]             = p.get("mrpType", "")
                    any_found = True
                else:
                    pdata["procurementError"] = p.get("error", "")
            except Exception as e:
                pdata["procurementError"] = str(e)

            try:
                raw = await get_material_valuation(mat, plant, s4=s4)
                v = _json.loads(raw)
                if not v.get("error"):
                    # ── Valuation setup ──
                    pdata["priceControl"]        = v.get("priceControl", "")
                    pdata["priceControlLabel"]   = v.get("priceControlLabel", "")
                    pdata["valuationClass"]      = v.get("valuationClass", "")
                    pdata["valuationCategory"]   = v.get("valuationCategory", "")
                    pdata["valuationType"]       = v.get("valuationType", "")
                    pdata["priceUnit"]           = v.get("priceUnit", 1)
                    pdata["currency"]            = v.get("currency", "")
                    # ── Prices ──
                    pdata["standardPrice"]       = v.get("standardPrice", 0)
                    pdata["movingAvgPrice"]      = v.get("movingAveragePrice", 0)
                    pdata["effectivePrice"]      = v.get("effectivePrice", 0)
                    pdata["oldStandardPrice"]    = v.get("oldStandardPrice", 0)
                    pdata["lastPriceChangeDate"] = v.get("lastPriceChangeDate", "")
                    # ── Inventory ──
                    pdata["totalStock"]          = v.get("totalStock", 0)
                    pdata["totalStockValue"]     = v.get("totalStockValue", 0)
                    pdata["valuationNote"]       = v.get("note", "")
                    any_found = True
                else:
                    pdata["valuationError"] = v.get("error", "")
            except Exception as e:
                pdata["valuationError"] = str(e)

            mat_result["plants"][plant] = pdata

        mat_result["found"] = any_found

        if not any_found:
            mat_result["errorMessage"] = (
                f"Material '{mat}' not found in SAP system (destination CIN_100). "
                "Please verify the material number exists in the connected S/4HANA system."
            )
            out[mat] = mat_result
            continue

        # ── info records (not plant-specific) ────────────────────────────────
        try:
            raw = await get_purchase_info_records(mat, plants[0], s4=s4)
            pir = _json.loads(raw)
            mat_result["infoRecords"] = {
                "vendorCount":        pir.get("vendorCount", 0),
                "hasMultipleSuppliers": pir.get("hasMultipleSuppliers", False),
                "vendors":            pir.get("infoRecords", []),
                "error":              pir.get("error", ""),
            }
        except Exception as e:
            mat_result["infoRecords"] = {"error": str(e), "vendorCount": 0, "vendors": []}

        # ── PO history per plant ──────────────────────────────────────────────
        mat_result["poHistory"] = {}
        for plant in plants:
            try:
                raw = await get_purchase_order_history(mat, plant, s4=s4)
                po = _json.loads(raw)
                mat_result["poHistory"][plant] = {
                    "totalOrders": po.get("totalOrders", 0),
                    "avgPrice":    po.get("avgPrice", 0),
                    "currency":    po.get("currency", ""),
                    "orders":      po.get("orders", [])[:10],   # cap at 10 for UI
                    "error":       po.get("error", ""),
                }
            except Exception as e:
                mat_result["poHistory"][plant] = {"error": str(e), "totalOrders": 0, "orders": []}

        # ── BOM comparison (pairwise: plant[0] vs plant[i]) ──────────────────
        mat_result["bom"] = {}
        for i in range(1, len(plants)):
            key = f"{plants[0]}_vs_{plants[i]}"
            try:
                raw = await get_bom_cross_plant(mat, plants[0], plants[i], s4=s4)
                bom = _json.loads(raw)
                mat_result["bom"][key] = {
                    "plant1":         plants[0],
                    "plant2":         plants[i],
                    "componentCount": bom.get("componentCount", 0),
                    "components":     bom.get("components", [])[:50],  # cap
                    "error":          bom.get("error", ""),
                    "status":         bom.get("status", ""),
                }
            except Exception as e:
                mat_result["bom"][key] = {"error": str(e), "plant1": plants[0], "plant2": plants[i]}

        # ── Make/Buy classification ───────────────────────────────────────────
        try:
            p0 = mat_result["plants"].get(plants[0], {})
            p1 = mat_result["plants"].get(plants[1], {})
            # Use effective price (S→std, V→MAP) for the most accurate variance
            ep0 = float(p0.get("effectivePrice") or p0.get("standardPrice") or p0.get("movingAvgPrice") or 0)
            ep1 = float(p1.get("effectivePrice") or p1.get("standardPrice") or p1.get("movingAvgPrice") or 0)
            ptype = p0.get("procurementType", "")
            vendor_count = mat_result["infoRecords"].get("vendorCount", 0)
            po_count = mat_result["poHistory"].get(plants[0], {}).get("totalOrders", 0)

            var_pct = 0.0
            if ep0 and ep1 and max(ep0, ep1) > 0:
                var_pct = abs(ep0 - ep1) / max(ep0, ep1) * 100

            cl = classify_make_buy(
                material_number=mat,
                cost_variance_percent=var_pct,
                procurement_type=ptype,
                has_multiple_suppliers=vendor_count > 1,
            )
            # Enrich classification with justification details
            cl["justification"] = {
                "effectivePricePlant0":    ep0,
                "effectivePricePlant1":    ep1,
                "priceControlPlant0":      p0.get("priceControlLabel", ""),
                "priceControlPlant1":      p1.get("priceControlLabel", ""),
                "oldStdPricePlant0":       p0.get("oldStandardPrice", 0),
                "lastPriceChangePlant0":   p0.get("lastPriceChangeDate", ""),
                "stockQtyPlant0":          p0.get("totalStock", 0),
                "stockValuePlant0":        p0.get("totalStockValue", 0),
                "stockQtyPlant1":          p1.get("totalStock", 0),
                "stockValuePlant1":        p1.get("totalStockValue", 0),
                "vendorCount":             vendor_count,
                "poCount":                 po_count,
                "procurementType":         ptype,
                "procurementTypeName":     p0.get("procurementTypeName", ""),
            }
            mat_result["classification"] = cl
        except Exception as e:
            mat_result["classification"] = {"error": str(e)}

        # ── ADDON: Pairwise cost comparison across ALL plant combinations ────
        try:
            # Live FX rates — fetched from open.er-api.com (refreshed every 30 min)
            _live = get_live_fx_rates()
            FX = {
                ("EUR","USD"): _live["EUR_USD"], ("USD","EUR"): _live["USD_EUR"],
                ("EUR","INR"): _live["EUR_INR"], ("INR","EUR"): _live["INR_EUR"],
                ("USD","INR"): _live["USD_INR"], ("INR","USD"): _live["INR_USD"],
                ("GBP","USD"): _live["GBP_USD"], ("USD","GBP"): _live["USD_GBP"],
                ("GBP","INR"): _live["GBP_INR"], ("INR","GBP"): _live["INR_GBP"],
                ("CHF","USD"): _live["CHF_USD"], ("USD","CHF"): _live["USD_CHF"],
                ("CHF","INR"): _live["CHF_INR"],
            }

            def fx_convert(amount, from_curr, to_curr):
                """Convert amount from from_curr to to_curr. Returns None if rate unknown."""
                if from_curr == to_curr:
                    return round(amount, 2)
                rate = FX.get((from_curr, to_curr))
                if rate:
                    return round(amount * rate, 2)
                # try reverse
                rate_rev = FX.get((to_curr, from_curr))
                if rate_rev:
                    return round(amount / rate_rev, 2)
                return None

            plant_prices = {}
            for plant in plants:
                pd = mat_result["plants"].get(plant, {})
                ep = float(pd.get("effectivePrice") or pd.get("standardPrice") or pd.get("movingAvgPrice") or 0)
                plant_prices[plant] = {
                    "price": ep,
                    "currency": pd.get("currency", ""),
                    "invalid": pd.get("invalid", False),
                }

            pairs = []
            for i in range(len(plants)):
                for j in range(i + 1, len(plants)):
                    pa, pb = plants[i], plants[j]
                    da, db = plant_prices.get(pa, {}), plant_prices.get(pb, {})
                    epa, epb = da.get("price", 0), db.get("price", 0)
                    curr_a, curr_b = da.get("currency", ""), db.get("currency", "")
                    cross = bool(curr_a and curr_b and curr_a != curr_b)
                    var_pct = None
                    cheaper = None
                    # FX conversion fields (always in USD and INR for cross-currency)
                    price1_usd = price2_usd = price1_inr = price2_inr = None
                    fx_var_pct_usd = fx_var_pct_inr = None
                    fx_note = ""
                    if epa and epb and cross:
                        # Convert both to USD
                        price1_usd = fx_convert(epa, curr_a, "USD") if curr_a != "USD" else epa
                        price2_usd = fx_convert(epb, curr_b, "USD") if curr_b != "USD" else epb
                        # Convert both to INR
                        price1_inr = fx_convert(epa, curr_a, "INR") if curr_a != "INR" else epa
                        price2_inr = fx_convert(epb, curr_b, "INR") if curr_b != "INR" else epb
                        # Variance in USD
                        if price1_usd and price2_usd:
                            fx_var_pct_usd = round(abs(price1_usd - price2_usd) / max(price1_usd, price2_usd) * 100, 2)
                            cheaper = pa if price1_usd <= price2_usd else pb
                            var_pct = fx_var_pct_usd
                        if price1_inr and price2_inr:
                            fx_var_pct_inr = round(abs(price1_inr - price2_inr) / max(price1_inr, price2_inr) * 100, 2)
                        fx_note = f"Indicative rates: 1 {curr_a}={FX.get((curr_a,'USD'), '?')} USD / 1 {curr_b}={FX.get((curr_b,'USD'), '?')} USD"
                    elif epa and epb and not cross:
                        var_pct = round(abs(epa - epb) / max(epa, epb) * 100, 2)
                        cheaper = pa if epa <= epb else pb
                    pairs.append({
                        "plant1": pa, "plant2": pb,
                        "price1": epa, "price2": epb,
                        "currency1": curr_a, "currency2": curr_b,
                        "crossCurrency": cross,
                        "variancePct": var_pct,
                        "cheaperPlant": cheaper,
                        "currencyNote": f"Cross-currency: {pa}={curr_a}, {pb}={curr_b}" if cross else "",
                        # FX normalised values
                        "price1USD": price1_usd,
                        "price2USD": price2_usd,
                        "price1INR": price1_inr,
                        "price2INR": price2_inr,
                        "variancePctUSD": fx_var_pct_usd,
                        "variancePctINR": fx_var_pct_inr,
                        "fxNote": fx_note,
                    })

            # Best plant = lowest USD-normalised price across all valid plants
            best_plant, best_reasoning = None, ""
            valid = [(p, v["price"], v["currency"]) for p, v in plant_prices.items()
                     if v["price"] > 0 and not v.get("invalid")]
            if valid:
                # Convert every plant price to USD for fair comparison
                usd_prices = []
                for plant, price, curr in valid:
                    usd = fx_convert(price, curr, "USD") if curr != "USD" else price
                    if usd:
                        usd_prices.append((plant, usd, price, curr))
                if usd_prices:
                    best_plant, best_usd, best_orig, best_curr = min(usd_prices, key=lambda x: x[1])
                    best_reasoning = (
                        f"Lowest cost: {best_orig} {best_curr} = {best_usd} USD "
                        f"(FX-normalised comparison across all plants)"
                    )
                else:
                    # fallback: same-currency group
                    groups: dict = {}
                    for plant, price, curr in valid:
                        groups.setdefault(curr, []).append((plant, price))
                    top_curr = max(groups, key=lambda c: len(groups[c]))
                    grp = groups[top_curr]
                    best_plant, best_price = min(grp, key=lambda x: x[1])
                    best_reasoning = f"Lowest price ({best_price} {top_curr}) among same-currency plants"

            mat_result["pairwiseComparisons"] = {
                "pairs": pairs,
                "bestPlant": best_plant,
                "bestPlantReasoning": best_reasoning,
            }
        except Exception as _e:
            mat_result["pairwiseComparisons"] = {"error": str(_e), "pairs": []}
        # ── END ADDON ────────────────────────────────────────────────────────

        out[mat] = mat_result

    return JSONResponse({"status": "success", "results": out})


# ═══════════════════════════════════════════════════════════════════════════════
#  /api/chat  — conversational LLM agent with thread persistence
# ═══════════════════════════════════════════════════════════════════════════════
async def api_chat(request: Request) -> JSONResponse:
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "Invalid JSON"}, status_code=400)

    message    = body.get("message", "").strip()
    context_id = body.get("contextId") or str(uuid.uuid4())
    context    = body.get("context", "")   # analysis summary passed from UI

    if not message:
        return JSONResponse({"error": "message is required"}, status_code=400)

    # Inject analysis context if provided
    full_msg = message
    if context:
        full_msg = f"[Analysis context: {context}]\n\n{message}"

    # Inject learned feedback hints so agent improves from 👍/👎
    feedback_hints = get_feedback_summary()
    if feedback_hints:
        full_msg = f"[LEARNED FROM USER FEEDBACK]\n{feedback_hints}\n[END FEEDBACK]\n\n{full_msg}"

    exc   = get_executor()
    tools = [*exc.bom_tools, *exc.skill_tools]

    try:
        result = await exc.agent.invoke(full_msg, context_id, tools=tools)
        return JSONResponse({
            "reply":     result.message,
            "status":    result.status,
            "contextId": context_id,
        })
    except Exception as e:
        logger.exception("api_chat error")
        return JSONResponse({"error": str(e), "contextId": context_id}, status_code=500)


async def api_feedback(request: Request) -> JSONResponse:
    """
    POST /api/feedback  — store user 👍/👎 vote for continuous improvement.
    Body: { question, answer, vote: "up"|"down" }
    The feedback is injected into every subsequent /api/chat call so BOMA 
    learns from past good/bad answers in real-time (no retraining needed).
    """
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "Invalid JSON"}, status_code=400)

    question = body.get("question", "").strip()
    answer   = body.get("answer", "").strip()
    vote     = body.get("vote", "").strip().lower()

    if not question or vote not in ("up", "down"):
        return JSONResponse({"error": "question and vote ('up'|'down') are required"}, status_code=400)

    record_feedback(question, answer, vote)
    return JSONResponse({"status": "recorded", "vote": vote})


# ═══════════════════════════════════════════════════════════════════════════════
#  App assembly
# ═══════════════════════════════════════════════════════════════════════════════
def build_app():  # noqa: C901
    skill = AgentSkill(
        id="bom-cost-optimization-agent",
        name="bom-cost-optimization-agent",
        description=(
            "AI-powered cross-plant BOM cost optimization: Make/Buy/Strategic Buy "
            "classification, procurement analysis, workflow triggers."
        ),
        tags=["bom", "cost", "optimization", "automotive"],
        examples=[
            "Compare BOM costs for F-10A between plants 1010 and 1710",
            "Which components should be Strategic Buy?",
        ],
    )
    agent_card = AgentCard(
        name="bom-cost-optimization-agent",
        description=(
            "AI-powered cross-plant BOM cost optimization for ABC Automotive. "
            "Classifies components as Make/Buy/Strategic Buy."
        ),
        url=os.environ.get("AGENT_PUBLIC_URL", f"http://{HOST}:{PORT}/"),
        version="1.0.0",
        default_input_modes=["text", "text/plain"],
        default_output_modes=["text", "text/plain"],
        capabilities=AgentCapabilities(streaming=True, push_notifications=False),
        skills=[skill],
    )
    a2a_server = A2AStarletteApplication(
        agent_card=agent_card,
        http_handler=DefaultRequestHandler(
            agent_executor=get_executor(),
            task_store=InMemoryTaskStore(),
        ),
    )
    a2a_app = a2a_server.build()

    # Wrap with top-level Starlette that owns the REST routes + CORS
    # Pure ASGI dispatcher — most reliable way to add routes alongside A2A
    async def _health(_scope, _receive, send):
        body = b'{"ok":true}'
        await send({"type":"http.response.start","status":200,"headers":[[b"content-type",b"application/json"],[b"content-length",str(len(body)).encode()]]})
        await send({"type":"http.response.body","body":body})

    async def _handle_api(endpoint, scope, receive, send):
        request = Request(scope, receive)
        response = await endpoint(request)
        await response(scope, receive, send)

    async def _cors_wrap(app_fn, scope, receive, send):
        """Add CORS headers to any response."""
        if scope.get("method") == "OPTIONS" or (scope.get("type") == "http" and scope.get("method") == "OPTIONS"):
            body = b""
            await send({"type":"http.response.start","status":204,"headers":[
                [b"access-control-allow-origin",b"*"],
                [b"access-control-allow-methods",b"GET, POST, OPTIONS"],
                [b"access-control-allow-headers",b"*"],
                [b"content-length",b"0"],
            ]})
            await send({"type":"http.response.body","body":body})
            return

        # Wrap send to inject CORS headers
        started = False
        async def cors_send(message):
            nonlocal started
            if message["type"] == "http.response.start" and not started:
                started = True
                headers = list(message.get("headers", []))
                headers.append([b"access-control-allow-origin", b"*"])
                message = {**message, "headers": headers}
            await send(message)

        await app_fn(scope, receive, cors_send)

    # ── Static UI files directory ─────────────────────────────────────────────
    _UI_DIR = os.path.join(os.path.dirname(__file__), "ui")
    _ui_exists = os.path.isdir(_UI_DIR)
    logger.info("UI dir: %s  exists=%s", _UI_DIR, _ui_exists)

    async def _serve_static(path: str, scope, receive, send):
        """Serve a file from the ui/ folder."""
        import mimetypes
        full = os.path.join(_UI_DIR, path.lstrip("/"))
        if not os.path.isfile(full):
            # SPA fallback → index.html
            full = os.path.join(_UI_DIR, "index.html")
        if not os.path.isfile(full):
            await send({"type":"http.response.start","status":404,"headers":[[b"content-length",b"9"]]})
            await send({"type":"http.response.body","body":b"Not found"})
            return
        mime, _ = mimetypes.guess_type(full)
        mime = (mime or "application/octet-stream").encode()
        with open(full, "rb") as f:
            data = f.read()
        await send({"type":"http.response.start","status":200,"headers":[
            [b"content-type", mime],
            [b"content-length", str(len(data)).encode()],
            [b"cache-control", b"no-store"],
        ]})
        await send({"type":"http.response.body","body":data})

    async def root_asgi(scope, receive, send):
        if scope["type"] != "http":
            await a2a_app(scope, receive, send)
            return
        path = scope.get("path", "")
        method = scope.get("method", "")

        if method == "OPTIONS" and path.startswith("/api/"):
            await send({"type":"http.response.start","status":204,"headers":[
                [b"access-control-allow-origin",b"*"],
                [b"access-control-allow-methods",b"POST, OPTIONS"],
                [b"access-control-allow-headers",b"content-type, authorization"],
                [b"content-length",b"0"],
            ]})
            await send({"type":"http.response.body","body":b""})
            return

        async def add_cors(message):
            if message["type"] == "http.response.start":
                headers = list(message.get("headers", []))
                headers.append([b"access-control-allow-origin", b"*"])
                message = {**message, "headers": headers}
            await send(message)

        if path == "/api/health":
            await _health(scope, receive, add_cors)
        elif path == "/api/analyse":
            await _handle_api(api_analyse, scope, receive, add_cors)
        elif path == "/api/chat":
            await _handle_api(api_chat, scope, receive, add_cors)
        elif path == "/api/feedback":
            await _handle_api(api_feedback, scope, receive, add_cors)
        elif _ui_exists and (path == "/" or path == "" or path.startswith("/assets/") or path.endswith(".svg") or path.endswith(".ico") or path.endswith(".html")):
            # Serve static UI files
            static_path = "index.html" if path in ("/", "") else path
            await _serve_static(static_path, scope, receive, send)
        else:
            await a2a_app(scope, receive, send)

    app = root_asgi

    return app


application = build_app()


def main():
    logger.info("Starting at http://%s:%d", HOST, PORT)
    uvicorn.run(application, host=HOST, port=PORT)


if __name__ == "__main__":
    main()
