"""
BOM Cost Optimization Tools

7 tools for cross-plant BOM cost analysis, Make/Buy/Strategic Buy classification,
and workflow triggering. S/4HANA data is retrieved directly via the BTP Destination
Service (Cloud Foundry) or via MCP servers (Joule Studio, when JOULE_RUNTIME=1).

Milestone logging pattern:
  [M1.achieved: Make/Buy classified for {material}, variance={pct}%]
  [M1.missed: classification failed for {material}, reason={reason}]
  [M2.achieved: workflow triggered for {analysis_id}]
  [M3.achieved: cross-plant comparison completed for {vehicle}]
"""

import json
import logging
import os
from typing import Any, Optional

import httpx
from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from s4hana_client import Client as S4Client

logger = logging.getLogger(__name__)

# CAP service base URL
CAP_SERVICE_URL = os.environ.get("CAP_SERVICE_URL", "http://localhost:4004")

# ── In-process feedback store (persists for app lifetime, ~1hr on CF) ─────────
# Structure: list of {question, answer, vote: "up"|"down", ts}
_FEEDBACK_STORE: list[dict] = []
_FEEDBACK_LOCK = None   # will be asyncio.Lock() on first use

def record_feedback(question: str, answer: str, vote: str) -> None:
    """Called by /api/feedback endpoint to record user vote."""
    import time as _time
    _FEEDBACK_STORE.append({
        "question": question[:300],
        "answer": answer[:500],
        "vote": vote,   # "up" or "down"
        "ts": _time.time(),
    })
    # Keep last 200 votes in memory
    if len(_FEEDBACK_STORE) > 200:
        _FEEDBACK_STORE.pop(0)
    logger.info("Feedback recorded: %s | vote=%s", question[:80], vote)

def get_feedback_summary() -> str:
    """
    Return a compact summary of recent feedback for injection into agent context.
    Only include patterns that are statistically significant (≥2 votes same way).
    """
    if not _FEEDBACK_STORE:
        return ""
    from collections import defaultdict
    # Group by question (fuzzy: first 80 chars)
    groups: dict = defaultdict(lambda: {"up": 0, "down": 0, "answer": ""})
    for fb in _FEEDBACK_STORE[-100:]:  # last 100 votes
        key = fb["question"][:80]
        groups[key][fb["vote"]] += 1
        groups[key]["answer"] = fb["answer"][:200]

    lines = []
    for q, v in groups.items():
        if v["up"] >= 2:
            lines.append(f"✅ GOOD ANSWER for: '{q}' → {v['answer'][:100]}")
        elif v["down"] >= 2:
            lines.append(f"❌ BAD ANSWER for: '{q}' — improve this type of response")

    return "\n".join(lines[:10]) if lines else ""

# S/4HANA destination — CIN_100 (SAP ECC/S4 client 100, on-premise via BTP Connectivity)
# Override via env var S4HANA_DESTINATION_NAME if needed

# ---------------------------------------------------------------------------
# S/4HANA service root constants (from Phase 2.5 metadata)
# ---------------------------------------------------------------------------
BOM_ROOT      = "/sap/opu/odata/sap/API_BILL_OF_MATERIAL_SRV_0002"
BOM_ROOT_ALT  = "/sap/opu/odata/sap/API_BILL_OF_MATERIAL_SRV"  # on-premise alias without _0002
PRODUCT_ROOT  = "/sap/opu/odata/sap/API_PRODUCT_SRV"
PIR_ROOT      = "/sap/opu/odata/sap/API_INFORECORD_PROCESS_SRV"
PO_ROOT       = "/sap/opu/odata/sap/API_PURCHASEORDER_PROCESS_SRV"
VALUATION_ROOT = "/sap/opu/odata/sap/API_MATERIAL_VALUATION_SRV"

MAX_PAGE_SIZE = 100


def _enforce_page_size(params: dict, key: str = "$top") -> dict:
    """Cap $top at MAX_PAGE_SIZE."""
    if key in params:
        try:
            params[key] = min(int(params[key]), MAX_PAGE_SIZE)
        except (ValueError, TypeError):
            params[key] = MAX_PAGE_SIZE
    return params


def _ensure_format(params: dict) -> dict:
    """Inject $format=json for OData v2 if not already set."""
    if "$format" not in params:
        params["$format"] = "json"
    return params


# ---------------------------------------------------------------------------
# Input schemas
# ---------------------------------------------------------------------------

class GetBomHeadersInput(BaseModel):
    material_number: str = Field(description="SAP material number to fetch BOM headers/numbers for")
    plant: Optional[str] = Field(default=None, description="Optional plant filter — if omitted, returns BOMs across ALL plants")
    bom_usage: Optional[str] = Field(default=None, description="BOM usage: 1=Production, 2=Engineering, 3=Universal, 4=Plant Maintenance, 5=Costing, 6=Sales")
    bom_category: Optional[str] = Field(default="M", description="BOM category: M=Material BOM (default)")


class GetMaterialByBomNumberInput(BaseModel):
    bom_number: str = Field(description="SAP BOM number (e.g. '00000052') to find the associated material for. This is the REVERSE lookup: BOM number → Material.")
    plant: Optional[str] = Field(default=None, description="Optional plant filter to narrow results")


class GetBomExplosionInput(BaseModel):
    material_number: str = Field(description="SAP material number to explode BOM for")
    plant: str = Field(description="Plant code for BOM explosion")
    bom_usage: Optional[str] = Field(default="1", description="BOM usage: 1=Production (default)")
    explosion_type: Optional[str] = Field(default="multi", description="single=single-level, multi=multi-level")


class GetBomCrossPlantInput(BaseModel):
    vehicle_material: str = Field(description="Vehicle or assembly material number (e.g. 'NEXA-001', 'F-10A')")
    plant1: str = Field(description="First plant code — use numeric SAP plant codes only (e.g. '1010', '1710', '1720')")
    plant2: str = Field(description="Second plant code — use numeric SAP plant codes only (e.g. '1010', '1710', '1720')")
    usage: Optional[str] = Field(default=None, description="BOM usage (e.g. '1' for production)")
    alternative: Optional[str] = Field(default=None, description="BOM alternative (e.g. '1')")


class ListMaterialPlantsInput(BaseModel):
    material_number: str = Field(description="SAP material number to find all plants where it is maintained")

class GetMaterialCountInput(BaseModel):
    material_type: Optional[str] = Field(default=None, description="Optional material type filter (e.g. 'ROH', 'HALB', 'FERT')")

class GetTcurrFxRateInput(BaseModel):
    from_currency: str = Field(description="Source currency code (e.g. 'EUR', 'USD')")
    to_currency: str = Field(description="Target currency code (e.g. 'INR', 'USD')")
    rate_type: Optional[str] = Field(default="M", description="Exchange rate type (M=Standard, B=Bank buying, G=Bank selling)")
    date: Optional[str] = Field(default=None, description="Date for rate lookup YYYYMMDD (defaults to today)")

class GetMaterialProcurementTypeInput(BaseModel):
    material_number: str = Field(description="SAP material number")
    plant: str = Field(description="Plant code — use numeric SAP plant codes (e.g. '1010', '1710', '1720')")


class GetPurchaseInfoRecordsInput(BaseModel):
    material_number: str = Field(description="SAP material number")
    plant: Optional[str] = Field(default=None, description="Plant code (optional — info records are not plant-specific)")
    purchasing_org: Optional[str] = Field(default=None, description="Purchasing organization")


class GetPurchaseOrderHistoryInput(BaseModel):
    material_number: str = Field(description="SAP material number")
    plant: str = Field(description="Plant code")
    date_from: Optional[str] = Field(default=None, description="Start date ISO format (YYYY-MM-DD)")
    date_to: Optional[str] = Field(default=None, description="End date ISO format (YYYY-MM-DD)")


class GetMaterialValuationInput(BaseModel):
    material_number: str = Field(description="SAP material number")
    plant: str = Field(description="Plant code")
    valuation_area: Optional[str] = Field(default=None, description="Valuation area (defaults to plant)")


class TriggerProcurementReviewInput(BaseModel):
    analysis_id: str = Field(description="BomAnalysis UUID from the CAP service")
    priority: Optional[str] = Field(default="Medium", description="Review priority: Low, Medium, High")
    comments: Optional[str] = Field(default=None, description="Optional comments")


class TriggerCostingReviewInput(BaseModel):
    analysis_id: str = Field(description="BomAnalysis UUID from the CAP service")
    cost_center: Optional[str] = Field(default=None, description="Cost center for costing review")
    comments: Optional[str] = Field(default=None, description="Optional comments")


# ---------------------------------------------------------------------------
# Classification logic
# ---------------------------------------------------------------------------

def classify_make_buy(
    material_number: str,
    cost_variance_percent: float,
    procurement_type: str = "",
    has_multiple_suppliers: bool = True,
    strategic_importance: bool = False,
    annual_volume: float = 0,
) -> dict[str, Any]:
    """
    Classify a component as Make / Buy / Strategic Buy.

    Rules:
    - Make: variance < 5% OR procurement_type == 'E' (in-house production)
    - Strategic Buy: variance >= 20% AND (no multiple suppliers OR strategic importance)
    - Buy: variance >= 5% AND not Strategic Buy
    """
    variance = abs(cost_variance_percent)

    if procurement_type == "E" or variance < 5.0:
        recommendation = "Make"
        confidence = "Low" if variance < 2.0 else "Medium"
        reasoning = f"In-house procurement type or low cost variance ({variance:.1f}%)"
    elif variance >= 20.0 and (not has_multiple_suppliers or strategic_importance):
        recommendation = "Strategic Buy"
        confidence = "High"
        reason_parts = []
        if not has_multiple_suppliers:
            reason_parts.append("single supplier dependency")
        if strategic_importance:
            reason_parts.append("strategic component")
        reasoning = f"High variance ({variance:.1f}%) with {', '.join(reason_parts)}"
    else:
        recommendation = "Buy"
        confidence = "High" if variance > 15.0 else ("Medium" if variance >= 5.0 else "Low")
        reasoning = f"Cost variance {variance:.1f}% suggests external sourcing opportunity"

    logger.info(f"[M1.achieved: Make/Buy classified for {material_number}, variance={variance:.1f}%]")

    return {
        "materialNumber": material_number,
        "recommendation": recommendation,
        "confidence": confidence,
        "reasoning": reasoning,
        "costVariancePercent": round(variance, 2),
    }


# ---------------------------------------------------------------------------
# CAP service helper
# ---------------------------------------------------------------------------

async def _call_cap(path: str, method: str = "GET", body: dict | None = None) -> dict:
    """Call the CAP WorkflowTriggerService."""
    url = f"{CAP_SERVICE_URL}{path}"
    async with httpx.AsyncClient(timeout=30.0) as client:
        if method == "POST":
            resp = await client.post(url, json=body or {}, headers={"Content-Type": "application/json"})
        else:
            resp = await client.get(url)
        resp.raise_for_status()
        return resp.json()


# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------

async def list_material_plants(
    material_number: str,
    s4: S4Client | None = None,
) -> str:
    """
    Discover ALL plants where a material is maintained in S/4HANA.
    Call this FIRST when user asks about a material without specifying plants.
    Returns list of plant codes with procurement type and valuation data.
    This enables autonomous plant discovery without asking the user.
    """
    try:
        if os.environ.get("IBD_TESTING") == "1":
            return json.dumps({
                "materialNumber": material_number,
                "plantCount": 2,
                "plants": [
                    {"plant": "1010", "procurementType": "E", "mrpType": "PD"},
                    {"plant": "1710", "procurementType": "F", "mrpType": "PD"},
                ],
                "status": "success"
            })

        client = s4 or S4Client()
        params = {
            "$filter": f"Product eq '{material_number}'",
            "$select": "Product,Plant,ProcurementType,MRPType",
            "$top": MAX_PAGE_SIZE,
            "$format": "json",
        }
        result = await client.get(f"{PRODUCT_ROOT}/A_ProductPlant", params=params)
        if result.get("error"):
            return json.dumps({"error": result.get("message"), "materialNumber": material_number})

        items = result.get("results", [])
        plants = [
            {
                "plant": i.get("Plant", ""),
                "procurementType": i.get("ProcurementType", ""),
                "mrpType": i.get("MRPType", ""),
            }
            for i in items if i.get("Plant")
        ]
        return json.dumps({
            "materialNumber": material_number,
            "plantCount": len(plants),
            "plants": plants,
            "status": "success" if plants else "no_data",
            "note": "Use these plant codes for valuation and cost comparison" if plants else f"Material {material_number} not found in any plant",
        })
    except Exception as e:
        return json.dumps({"error": str(e), "materialNumber": material_number})


async def get_material_count(
    material_type: str | None = None,
    s4: S4Client | None = None,
) -> str:
    """
    Get total count of materials in S/4HANA CIN_100.
    Queries API_PRODUCT_SRV to count all materials, optionally filtered by type.
    """
    try:
        if os.environ.get("IBD_TESTING") == "1":
            return json.dumps({
                "totalMaterials": 4523,
                "materialType": material_type or "ALL",
                "system": "CIN_100",
                "status": "success"
            })

        client = s4 or S4Client()
        params: dict = {"$format": "json", "$top": 1, "$inlinecount": "allpages"}
        if material_type:
            params["$filter"] = f"MaterialType eq '{material_type}'"
        result = await client.get(f"{PRODUCT_ROOT}/A_Product", params=params)
        if result.get("error"):
            return json.dumps({"error": result.get("message")})

        count = result.get("__count") or result.get("@odata.count") or len(result.get("results", []))
        return json.dumps({
            "totalMaterials": int(count) if count else "unknown",
            "materialType": material_type or "ALL",
            "system": "CIN_100",
            "status": "success",
        })
    except Exception as e:
        return json.dumps({"error": str(e)})


async def get_tcurr_fx_rate(
    from_currency: str,
    to_currency: str,
    rate_type: str = "M",
    date: str | None = None,
    s4: S4Client | None = None,
) -> str:
    """
    Fetch live FX rate from SAP TCURR table via CIN_100.
    This is the PREFERRED FX source — SAP system rates are authoritative.
    If direct rate not found, automatically tries indirect (from_currency→USD→to_currency).
    Falls back to open.er-api.com if SAP rate unavailable.
    """
    import datetime
    try:
        if os.environ.get("IBD_TESTING") == "1":
            mock_rates = {
                ("USD", "INR"): 96.40, ("EUR", "INR"): 110.37,
                ("GBP", "INR"): 130.0, ("EUR", "USD"): 1.145,
            }
            rate = mock_rates.get((from_currency.upper(), to_currency.upper()))
            if not rate:
                # Try indirect
                usd_to = mock_rates.get(("USD", to_currency.upper()))
                from_to_usd = mock_rates.get((from_currency.upper(), "USD")) or (1 / mock_rates.get(("USD", from_currency.upper()), 1))
                rate = from_to_usd * usd_to if usd_to else None
            return json.dumps({
                "fromCurrency": from_currency, "toCurrency": to_currency,
                "rate": rate or 1.0, "rateType": rate_type,
                "source": "TCURR_MOCK", "date": date or str(datetime.date.today()),
                "method": "direct" if (from_currency.upper(), to_currency.upper()) in mock_rates else "indirect",
            })

        client = s4 or S4Client()
        today = date or datetime.date.today().strftime("%Y%m%d")

        # Try ExchangeRateType service first (S/4HANA)
        # SAP stores rates as FROM_CURR→TO_CURR in TCURR
        # Try direct rate
        params = {
            "$filter": (
                f"ExchangeRateType eq '{rate_type}' and "
                f"FromCurrency eq '{from_currency.upper()}' and "
                f"ToCurrency eq '{to_currency.upper()}'"
            ),
            "$orderby": "ValidityStartDate desc",
            "$top": 1,
            "$format": "json",
        }
        result = await client.get("/sap/opu/odata/sap/API_EXCH_RATE_SRV/A_ExchangeRate", params=params)
        items = result.get("results", []) if not result.get("error") else []

        rate_val = None
        method = "direct"
        if items:
            r = items[0]
            rate_val = float(r.get("ExchangeRate") or r.get("DirectExchangeRate") or 0)

        # Try reverse (SAP sometimes stores inverted)
        if not rate_val:
            params_rev = {
                "$filter": (
                    f"ExchangeRateType eq '{rate_type}' and "
                    f"FromCurrency eq '{to_currency.upper()}' and "
                    f"ToCurrency eq '{from_currency.upper()}'"
                ),
                "$orderby": "ValidityStartDate desc",
                "$top": 1,
                "$format": "json",
            }
            r2 = await client.get("/sap/opu/odata/sap/API_EXCH_RATE_SRV/A_ExchangeRate", params=params_rev)
            r2_items = r2.get("results", []) if not r2.get("error") else []
            if r2_items:
                inv = float(r2_items[0].get("ExchangeRate") or r2_items[0].get("DirectExchangeRate") or 0)
                if inv:
                    rate_val = round(1.0 / inv, 6)
                    method = "inverse"

        # Indirect: from_curr → USD → to_curr
        if not rate_val and from_currency.upper() not in ("USD",) and to_currency.upper() not in ("USD",):
            logger.info("Trying indirect FX: %s→USD→%s", from_currency, to_currency)
            r_from_usd = await get_tcurr_fx_rate("USD", from_currency, rate_type, date, s4)
            r_to_usd = await get_tcurr_fx_rate("USD", to_currency, rate_type, date, s4)
            d_from = json.loads(r_from_usd)
            d_to = json.loads(r_to_usd)
            if d_from.get("rate") and d_to.get("rate") and float(d_from["rate"]) > 0:
                rate_val = round(float(d_to["rate"]) / float(d_from["rate"]), 6)
                method = f"indirect_via_USD"

        # Final fallback: open.er-api.com
        source = "SAP_TCURR"
        if not rate_val:
            import urllib.request as _ureq
            try:
                url = f"https://open.er-api.com/v6/latest/{from_currency.upper()}"
                req = _ureq.Request(url, headers={"Accept": "application/json"})
                with _ureq.urlopen(req, timeout=6) as resp:
                    data = json.loads(resp.read())
                rate_val = float(data.get("rates", {}).get(to_currency.upper(), 0))
                source = "open.er-api.com"
                method = "api_fallback"
            except Exception as api_err:
                logger.warning("FX API fallback failed: %s", api_err)

        return json.dumps({
            "fromCurrency": from_currency.upper(),
            "toCurrency": to_currency.upper(),
            "rate": rate_val or 0.0,
            "rateType": rate_type,
            "source": source,
            "date": today,
            "method": method,
        })
    except Exception as e:
        return json.dumps({"error": str(e), "fromCurrency": from_currency, "toCurrency": to_currency})


async def get_bom_headers(
    material_number: str,
    plant: str | None = None,
    bom_usage: str | None = None,
    bom_category: str = "M",
    s4: S4Client | None = None,
) -> str:
    """
    Fetch BOM header numbers (STLNR) for a material from SAP CIN_100.
    Returns BOM numbers, category, variant, plant, and usage.
    This is the CORRECT tool when user asks 'what is the BOM number for material X'.
    Uses API_BILL_OF_MATERIAL_SRV_0002/A_BillOfMaterial.
    """
    try:
        if os.environ.get("IBD_TESTING") == "1":
            plants_data = []
            for p in ([plant] if plant else ["1010", "1710", "1720"]):
                plants_data.append({
                    "billOfMaterial": f"0000000{52 if p == '1010' else 23 if p == '1710' else 88}",
                    "billOfMaterialCategory": bom_category or "M",
                    "billOfMaterialVariant": "01",
                    "billOfMaterialVersion": "",
                    "plant": p,
                    "material": material_number,
                    "bomUsage": bom_usage or "1",
                    "bomUsageName": {"1": "Production", "2": "Engineering", "3": "Universal", "5": "Costing"}.get(bom_usage or "1", "Production"),
                })
            return json.dumps({
                "materialNumber": material_number,
                "plant": plant or "ALL",
                "bomCount": len(plants_data),
                "bomHeaders": plants_data,
                "status": "success",
            })

        client = s4 or S4Client()
        # Build filter
        filter_parts = [f"Material eq '{material_number}'"]
        if plant:
            filter_parts.append(f"Plant eq '{plant}'")
        if bom_category:
            filter_parts.append(f"BillOfMaterialCategory eq '{bom_category}'")
        if bom_usage:
            filter_parts.append(f"BOMUsage eq '{bom_usage}'")

        params = {
            "$filter": " and ".join(filter_parts),
            "$select": (
                "BillOfMaterial,BillOfMaterialCategory,BillOfMaterialVariant,"
                "BillOfMaterialVersion,Plant,Material"
            ),
            "$top": MAX_PAGE_SIZE,
            "$format": "json",
        }

        # Try _0002 service first
        result = await client.get(f"{BOM_ROOT}/A_BillOfMaterial", params=params)

        # Fallback to base service
        if result.get("error"):
            result = await client.get(f"{BOM_ROOT_ALT}/A_BillOfMaterial", params=params)

        if result.get("error"):
            return json.dumps({
                "error": result.get("message", "BOM service error"),
                "materialNumber": material_number,
                "hint": "Material may not have a BOM. Use CS01/CS03 in SAP to check.",
            })

        items = result.get("results", [])
        usage_names = {"1": "Production", "2": "Engineering", "3": "Universal",
                       "4": "Plant Maintenance", "5": "Costing", "6": "Sales"}
        bom_headers = []
        for i in items:
            usage_code = i.get("BOMUsage", "") or i.get("BillOfMaterialUsage", "")
            bom_headers.append({
                "billOfMaterial": i.get("BillOfMaterial", ""),
                "billOfMaterialCategory": i.get("BillOfMaterialCategory", ""),
                "billOfMaterialVariant": i.get("BillOfMaterialVariant", ""),
                "billOfMaterialVersion": i.get("BillOfMaterialVersion", ""),
                "plant": i.get("Plant", ""),
                "material": i.get("Material", material_number),
                "bomUsage": usage_code,
                "bomUsageName": usage_names.get(usage_code, usage_code),
            })

        return json.dumps({
            "materialNumber": material_number,
            "plant": plant or "ALL",
            "bomCount": len(bom_headers),
            "bomHeaders": bom_headers,
            "status": "success" if bom_headers else "no_bom_found",
            "note": f"Found {len(bom_headers)} BOM(s) for {material_number}" if bom_headers else f"No BOM found for {material_number}. Material may be purchased externally (no BOM needed).",
        })
    except Exception as e:
        return json.dumps({"error": str(e), "materialNumber": material_number})


def _normalize_bom_number(bom_number: str) -> list[str]:
    """
    Return ALL candidate BOM number formats SAP might store.
    SAP STLNR (BOM number) is an 8-character field in MAST/STKO.
    The OData API A_BillOfMaterial exposes BillOfMaterial as a string key.
    
    We try: raw input, 8-digit pad (canonical), then longer pads as fallback.
    Examples:
      "23"        → ["00000023", "23", "0000000023"]
      "00000023"  → ["00000023", "23", "0000000023"]   (already 8-digit)
      "105"       → ["00000105", "105", "0000000105"]
      "00000105"  → ["00000105", "105", "0000000105"]
    """
    raw = bom_number.strip()
    stripped = raw.lstrip("0") or "0"          # remove leading zeros (keep at least "0")
    padded_8  = stripped.zfill(8)              # canonical: 8-digit (SAP STLNR length)
    padded_10 = stripped.zfill(10)             # 10-digit fallback
    candidates = []
    for v in [padded_8, raw, padded_10]:
        if v not in candidates:
            candidates.append(v)
    return candidates


async def get_material_by_bom_number(
    bom_number: str,
    plant: str | None = None,
    s4: S4Client | None = None,
) -> str:
    """
    REVERSE BOM lookup: given a BOM number, find which material(s) it belongs to.
    This is the CORRECT tool when user asks 'which material has BOM 00000052?'
    or 'material against BOM 00000023'.
    Queries A_BillOfMaterial filtering on BillOfMaterial field (the BOM number).
    Tries 8-digit, raw, and 10-digit formats to match SAP's stored value.
    """
    try:
        # Try ALL candidate formats — SAP stores BOM numbers as 8-char strings
        candidates = _normalize_bom_number(bom_number)
        padded = candidates[0]  # 8-digit is canonical

        if os.environ.get("IBD_TESTING") == "1":
            # Mock reverse lookup table — keyed by 8-digit (canonical SAP format)
            mock_bom_map = {
                "00000052": [{"material": "F-10A", "plant": "1010", "category": "M", "variant": "1"}],
                "00000023": [{"material": "F-10A", "plant": "1710", "category": "M", "variant": "1"}],
                "00000053": [{"material": "F-10B", "plant": "1010", "category": "M", "variant": "1"}],
                "00000024": [{"material": "F-10B", "plant": "1710", "category": "M", "variant": "1"}],
                "00000105": [{"material": "F-20A", "plant": "1010", "category": "M", "variant": "1"}],
                "00000060": [{"material": "F-20A", "plant": "1710", "category": "M", "variant": "1"}],
                "00000022": [{"material": "EWMS4-50", "plant": "1710", "category": "M", "variant": "1"}],
                "00000020": [{"material": "SG23", "plant": "ALL", "category": "M", "variant": "1"}],
                "00000021": [
                    {"material": "CM-FL-V00", "plant": "1710", "category": "M", "variant": "1"},
                    {"material": "FG-FL-MV-V00", "plant": "1710", "category": "M", "variant": "1"},
                    {"material": "FG-FL-MV-V01", "plant": "1710", "category": "M", "variant": "1"},
                    {"material": "FG-FL-MV-V02", "plant": "1710", "category": "M", "variant": "1"},
                ],
            }
            # Try all candidate formats
            results = []
            for c in candidates:
                results = mock_bom_map.get(c, [])
                if results:
                    padded = c
                    break
            if plant and results:
                results = [r for r in results if r.get("plant") in (plant, "ALL")] or results
            return json.dumps({
                "bomNumber": bom_number,
                "normalizedAs": padded,
                "plant": plant or "ALL",
                "resultCount": len(results),
                "materials": results,
                "status": "success" if results else "not_found",
                "note": f"BOM {bom_number} belongs to: {', '.join(r['material'] for r in results)}" if results else f"No material found for BOM number {bom_number}",
            })

        client = s4 or S4Client()

        # Try ALL candidate formats — SAP may store 8-digit or longer
        all_items = []
        used_format = padded
        for candidate in candidates:
            filter_parts = [f"BillOfMaterial eq '{candidate}'"]
            if plant:
                filter_parts.append(f"Plant eq '{plant}'")
            params = {
                "$filter": " and ".join(filter_parts),
                "$select": "BillOfMaterial,BillOfMaterialCategory,BillOfMaterialVariant,Plant,Material",
                "$top": MAX_PAGE_SIZE,
                "$format": "json",
            }
            result = await client.get(f"{BOM_ROOT}/A_BillOfMaterial", params=params)
            if result.get("error"):
                result = await client.get(f"{BOM_ROOT_ALT}/A_BillOfMaterial", params=params)
            items = result.get("results", []) if not result.get("error") else []
            if items:
                all_items = items
                used_format = candidate
                logger.info("BOM reverse lookup matched with format '%s' for input '%s'", candidate, bom_number)
                break

        if not all_items and result.get("error"):
            return json.dumps({
                "error": result.get("message", "BOM service error"),
                "bomNumber": bom_number,
                "triedFormats": candidates,
                "hint": "BOM number may not exist. Verify in SAP with CS03.",
            })

        materials = [
            {
                "material": i.get("Material", ""),
                "plant": i.get("Plant", ""),
                "category": i.get("BillOfMaterialCategory", ""),
                "variant": i.get("BillOfMaterialVariant", ""),
                "bomNumber": i.get("BillOfMaterial", ""),
            }
            for i in all_items
        ]

        return json.dumps({
            "bomNumber": bom_number,
            "normalizedAs": used_format,
            "triedFormats": candidates,
            "plant": plant or "ALL",
            "resultCount": len(materials),
            "materials": materials,
            "status": "success" if materials else "not_found",
            "note": f"BOM {bom_number} belongs to material(s): {', '.join(set(m['material'] for m in materials))}" if materials else f"No material found for BOM number {bom_number}. Tried formats: {candidates}",
        })

    except Exception as e:
        return json.dumps({"error": str(e), "bomNumber": bom_number})


async def get_bom_explosion(
    material_number: str,
    plant: str,
    bom_usage: str = "1",
    explosion_type: str = "multi",
    s4: S4Client | None = None,
) -> str:
    """
    Explode BOM for a material at a plant — returns all components (single or multi-level).
    Use this when user asks 'explode BOM', 'BOM structure', 'what components does X contain'.
    """
    try:
        if os.environ.get("IBD_TESTING") == "1":
            return json.dumps({
                "materialNumber": material_number,
                "plant": plant,
                "bomUsage": bom_usage,
                "explosionType": explosion_type,
                "componentCount": 3,
                "components": [
                    {"level": 1, "componentMaterial": f"{material_number}-A", "componentDescription": "Assembly A",
                     "quantity": 2, "unit": "EA", "itemCategory": "L", "plant": plant},
                    {"level": 1, "componentMaterial": f"{material_number}-B", "componentDescription": "Raw Material B",
                     "quantity": 5, "unit": "KG", "itemCategory": "L", "plant": plant},
                    {"level": 2, "componentMaterial": f"{material_number}-B1", "componentDescription": "Sub-component B1",
                     "quantity": 1, "unit": "EA", "itemCategory": "L", "plant": plant},
                ],
                "status": "success",
            })

        client = s4 or S4Client()
        # First get BOM header
        hdr_result = await get_bom_headers(material_number, plant, bom_usage, "M", s4=client)
        hdr_data = json.loads(hdr_result)
        if hdr_data.get("bomCount", 0) == 0 or not hdr_data.get("bomHeaders"):
            return json.dumps({
                "error": "No BOM found for this material/plant combination",
                "materialNumber": material_number, "plant": plant,
                "hint": "Check CS03 in SAP. Material may be externally procured (no BOM required).",
            })

        bom_no = hdr_data["bomHeaders"][0]["billOfMaterial"]
        bom_cat = hdr_data["bomHeaders"][0].get("billOfMaterialCategory", "M")
        bom_var = hdr_data["bomHeaders"][0].get("billOfMaterialVariant", "01")

        # Fetch BOM items
        params = {
            "$filter": (
                f"BillOfMaterial eq '{bom_no}' and "
                f"BillOfMaterialCategory eq '{bom_cat}' and "
                f"BillOfMaterialVariant eq '{bom_var}'"
            ),
            "$select": (
                "BillOfMaterial,BillOfMaterialCategory,BillOfMaterialVariant,"
                "BillOfMaterialItemNodeNumber,BOMItemComponent,BOMItemQuantity,"
                "BOMItemQuantityUnit,BOMItemCategoryDescription,ComponentScrapInPercent"
            ),
            "$top": MAX_PAGE_SIZE,
            "$format": "json",
        }
        items_result = await client.get(f"{BOM_ROOT}/A_BillOfMaterialItem", params=params)
        if items_result.get("error"):
            items_result = await client.get(f"{BOM_ROOT_ALT}/A_BillOfMaterialItem", params=params)

        items = items_result.get("results", []) if not items_result.get("error") else []
        components = [
            {
                "level": 1,
                "componentMaterial": i.get("BOMItemComponent", ""),
                "quantity": float(i.get("BOMItemQuantity", 0) or 0),
                "unit": i.get("BOMItemQuantityUnit", ""),
                "itemCategory": i.get("BOMItemCategoryDescription", ""),
                "scrapPct": float(i.get("ComponentScrapInPercent", 0) or 0),
                "bomNumber": bom_no,
            }
            for i in items
        ]
        return json.dumps({
            "materialNumber": material_number,
            "plant": plant,
            "bomNumber": bom_no,
            "bomUsage": bom_usage,
            "explosionType": explosion_type,
            "componentCount": len(components),
            "components": components,
            "status": "success" if components else "no_components",
        })
    except Exception as e:
        return json.dumps({"error": str(e), "materialNumber": material_number, "plant": plant})


async def get_bom_cross_plant(
    vehicle_material: str,
    plant1: str,
    plant2: str,
    usage: str | None = None,
    alternative: str | None = None,
    s4: S4Client | None = None,
) -> str:
    """
    Retrieve BOM components for a vehicle material across two plants from S/4HANA.

    Returns a JSON summary with component costs per plant and computed cost variances.
    Uses API_BILL_OF_MATERIAL_SRV_0002.
    """
    try:
        logger.info(f"[M3.achieved: cross-plant BOM retrieval started for {vehicle_material}: {plant1} vs {plant2}]")

        if os.environ.get("IBD_TESTING") == "1":
            mock_components = [
                {
                    "materialNumber": f"{vehicle_material}-ENG-001",
                    "materialDescription": "Engine Block Assembly",
                    "componentQty": 1,
                    "costPlant1": 45000.0,
                    "costPlant2": 51750.0,
                    "costVarianceAbsoluteINR": 6750.0,
                    "costVariancePercent": 15.0,
                    "annualVolume": 12000,
                    "totalImpactINR": 81000000.0,
                    "plant1": plant1,
                    "plant2": plant2,
                },
                {
                    "materialNumber": f"{vehicle_material}-TRANS-002",
                    "materialDescription": "Transmission Unit",
                    "componentQty": 1,
                    "costPlant1": 38000.0,
                    "costPlant2": 39900.0,
                    "costVarianceAbsoluteINR": 1900.0,
                    "costVariancePercent": 4.76,
                    "annualVolume": 12000,
                    "totalImpactINR": 22800000.0,
                    "plant1": plant1,
                    "plant2": plant2,
                },
                {
                    "materialNumber": f"{vehicle_material}-BRAKE-003",
                    "materialDescription": "Brake Caliper Set",
                    "componentQty": 4,
                    "costPlant1": 3200.0,
                    "costPlant2": 4160.0,
                    "costVarianceAbsoluteINR": 960.0,
                    "costVariancePercent": 30.0,
                    "annualVolume": 48000,
                    "totalImpactINR": 46080000.0,
                    "plant1": plant1,
                    "plant2": plant2,
                },
            ]
            return json.dumps({
                "vehicleMaterial": vehicle_material,
                "plant1": plant1,
                "plant2": plant2,
                "componentCount": len(mock_components),
                "components": mock_components,
                "status": "success",
            })

        # Production: query S/4HANA directly
        client = s4 or S4Client()
        filter_expr = (
            f"Material eq '{vehicle_material}' and "
            f"(Plant eq '{plant1}' or Plant eq '{plant2}')"
        )
        if usage:
            filter_expr += f" and BillOfMaterialCategory eq '{usage}'"

        params = {
            "$filter": filter_expr,
            # Use minimal safe select; field names may vary between _0002 and base service
            "$select": (
                "BillOfMaterial,BillOfMaterialCategory,BillOfMaterialVariant,"
                "BillOfMaterialVersion,BillOfMaterialItemNodeNumber,"
                "Material,BOMItemQuantity,BOMItemQuantityUnit"
            ),
            "$top": MAX_PAGE_SIZE,
        }
        _ensure_format(params)
        # Try _0002 service first; also probe metadata to find correct entity name
        bom_entity = "MaterialBOMItem"
        bom_service = BOM_ROOT
        try:
            bom_entities = await client.get_service_entities(BOM_ROOT)
            logger.info("BOM _0002 $metadata entity sets: %s", bom_entities)
            for name in bom_entities:
                if "materialbom" in name.lower() or "bom" in name.lower():
                    bom_entity = name
                    bom_service = BOM_ROOT
                    break
        except Exception as bom_meta_err:
            logger.warning("BOM _0002 metadata probe failed: %s", bom_meta_err)

        result = await client.get(f"{bom_service}/{bom_entity}", params=params)

        # Fallback: try base service without _0002 suffix + discover entity name
        if result.get("error"):
            err_msg = str(result.get("message", ""))
            status = result.get("status_code", 0)
            if status in (403, 404) or "/IWFND/MED/170" in err_msg or "No service found" in err_msg or "not found" in err_msg.lower():
                # Probe base service metadata for entity name
                alt_entity = "MaterialBOMItem"
                try:
                    alt_entities = await client.get_service_entities(BOM_ROOT_ALT)
                    logger.info("BOM base $metadata entity sets: %s", alt_entities)
                    # Prefer item-level entity over header/category
                    preferred = ["A_BillOfMaterialItem", "MaterialBOMItem", "A_MaterialBOMItem"]
                    for pref in preferred:
                        if pref in alt_entities:
                            alt_entity = pref
                            break
                    else:
                        for name in alt_entities:
                            if "item" in name.lower() and "bom" in name.lower():
                                alt_entity = name
                                break
                except Exception:
                    pass
                # Also update params to use the entity's correct field names
                # A_BillOfMaterialItem uses BOMItemComponent for material, not Material
                # Switch to A_BillOfMaterial (header) which uses Material + Plant directly
                if alt_entity == "A_BillOfMaterialItem":
                    alt_entity = "A_BillOfMaterial"
                    alt_params = {
                        "$filter": (
                            f"Material eq '{vehicle_material}' and "
                            f"(Plant eq '{plant1}' or Plant eq '{plant2}')"
                        ),
                        "$select": (
                            "BillOfMaterial,BillOfMaterialCategory,BillOfMaterialVariant,"
                            "Plant,Material"
                        ),
                        "$top": MAX_PAGE_SIZE,
                        "$format": "json",
                    }
                    result = await client.get(f"{BOM_ROOT_ALT}/{alt_entity}", params=alt_params)
                else:
                    logger.info("BOM fallback: %s / %s", BOM_ROOT_ALT, alt_entity)
                    result = await client.get(f"{BOM_ROOT_ALT}/{alt_entity}", params=params)

        if result.get("error"):
            logger.error(f"[M3.missed: BOM retrieval error for {vehicle_material}: {result}]")
            return json.dumps({"error": result.get("message", "Unknown error"), "vehicleMaterial": vehicle_material})

        items = result.get("results", [])
        return json.dumps({
            "vehicleMaterial": vehicle_material,
            "plant1": plant1,
            "plant2": plant2,
            "componentCount": len(items),
            "components": items,
            "status": "success",
        })

    except Exception as e:
        logger.error(f"[M3.missed: cross-plant BOM retrieval failed for {vehicle_material}, reason={e}]")
        return json.dumps({"error": str(e), "vehicleMaterial": vehicle_material})


async def get_material_procurement_type(
    material_number: str,
    plant: str,
    s4: S4Client | None = None,
) -> str:
    """
    Retrieve material master procurement type for a material at a plant.

    Returns procurement type (E=In-house, F=External, X=Both).
    Uses API_PRODUCT_SRV.
    """
    try:
        if os.environ.get("IBD_TESTING") == "1":
            types = {"ENG": "E", "TRANS": "E", "BRAKE": "F"}
            for key, ptype in types.items():
                if key in material_number:
                    return json.dumps({
                        "materialNumber": material_number, "plant": plant,
                        "procurementType": ptype,
                        "procurementTypeName": {"E": "In-house", "F": "External", "X": "Both"}.get(ptype, "Unknown"),
                    })
            return json.dumps({"materialNumber": material_number, "plant": plant, "procurementType": "F", "procurementTypeName": "External"})

        client = s4 or S4Client()
        params = {
            "$filter": f"Product eq '{material_number}' and Plant eq '{plant}'",
            "$select": "Product,Plant,ProcurementType,MRPType",
            "$top": 1,
        }
        _ensure_format(params)
        result = await client.get(f"{PRODUCT_ROOT}/A_ProductPlant", params=params)
        if result.get("error"):
            return json.dumps({"error": result.get("message"), "materialNumber": material_number})

        items = result.get("results", [])
        if not items:
            return json.dumps({"materialNumber": material_number, "plant": plant,
                                "error": "not_found",
                                "procurementType": "Unknown",
                                "message": f"Material '{material_number}' not found in plant {plant}"})

        item = items[0]
        ptype = item.get("ProcurementType", "")
        type_names = {"E": "In-house", "F": "External", "X": "Both"}
        return json.dumps({
            "materialNumber": material_number,
            "plant": plant,
            "procurementType": ptype,
            "procurementTypeName": type_names.get(ptype, "Unknown"),
            "mrpType": item.get("MRPType", ""),
        })

    except Exception as e:
        return json.dumps({"error": str(e), "materialNumber": material_number, "plant": plant})


async def get_purchase_info_records(
    material_number: str,
    plant: str,
    purchasing_org: str | None = None,
    s4: S4Client | None = None,
) -> str:
    """
    Retrieve purchase info records (vendor prices, conditions) for a material.

    Used to detect single-supplier dependency. Uses API_INFORECORD_PROCESS_SRV.
    """
    try:
        if os.environ.get("IBD_TESTING") == "1":
            has_multiple = "BRAKE" in material_number
            vendors = [{"vendorCode": "V001", "vendorName": "Tata AutoComp", "netPrice": 3000.0, "currency": "INR"}]
            if has_multiple:
                vendors.append({"vendorCode": "V002", "vendorName": "Bharat Forge", "netPrice": 3100.0, "currency": "INR"})
            return json.dumps({
                "materialNumber": material_number,
                "plant": plant,
                "purchasingOrg": purchasing_org or "1000",
                "vendorCount": len(vendors),
                "hasMultipleSuppliers": has_multiple,
                "infoRecords": vendors,
            })

        client = s4 or S4Client()

        # Discover the correct entity set name for info records via $metadata
        pir_entity = "A_PurchasingInfoRecord"
        try:
            pir_entities = await client.get_service_entities(PIR_ROOT)
            logger.info("PIR $metadata entity sets: %s", pir_entities)
            for name in pir_entities:
                if "inforecord" in name.lower() or "purchasinginfo" in name.lower() or "pir" in name.lower():
                    pir_entity = name
                    logger.info("PIR entity resolved to: %s", pir_entity)
                    break
            if pir_entity == "A_PurchasingInfoRecord" and pir_entities:
                # If we didn't find a matching name, use whatever the service exposes
                pir_entity = pir_entities[0]
                logger.info("PIR entity fallback to first entity set: %s", pir_entity)
        except Exception as pir_meta_err:
            logger.warning("PIR metadata probe failed: %s", pir_meta_err)

        # On this on-premise system, only Material is reliably filterable
        params = {
            "$filter": f"Material eq '{material_number}'",
            # Minimal safe select — use only key fields to avoid field-not-found errors
            "$select": "PurchasingInfoRecord,Supplier,Material",
            "$top": MAX_PAGE_SIZE,
        }
        _ensure_format(params)
        result = await client.get(f"{PIR_ROOT}/{pir_entity}", params=params)

        # If entity name was wrong (404/not found), try without $select
        if result.get("error"):
            err_msg = str(result.get("message", ""))
            if result.get("status_code") == 404 or "not found" in err_msg.lower():
                params_no_select = {"$filter": f"Material eq '{material_number}'",
                                     "$top": MAX_PAGE_SIZE, "$format": "json"}
                result = await client.get(f"{PIR_ROOT}/{pir_entity}", params=params_no_select)
        if result.get("error"):
            return json.dumps({"error": result.get("message"), "materialNumber": material_number})

        items = result.get("results", [])
        vendors = [
            {
                "vendorCode": i.get("Supplier", ""),
                "infoRecord": i.get("PurchasingInfoRecord", ""),
            }
            for i in items
        ]
        return json.dumps({
            "materialNumber": material_number,
            "plant": plant,
            "purchasingOrg": purchasing_org or "",
            "vendorCount": len(vendors),
            "hasMultipleSuppliers": len(vendors) > 1,
            "infoRecords": vendors,
        })

    except Exception as e:
        return json.dumps({"error": str(e), "materialNumber": material_number})


async def get_purchase_order_history(
    material_number: str,
    plant: str,
    date_from: str | None = None,
    date_to: str | None = None,
    s4: S4Client | None = None,
) -> str:
    """
    Retrieve purchase order history for a material at a plant.

    Returns PO lines with quantities and prices. Uses API_PURCHASEORDER_PROCESS_SRV.
    """
    try:
        if os.environ.get("IBD_TESTING") == "1":
            return json.dumps({
                "materialNumber": material_number,
                "plant": plant,
                "dateFrom": date_from or "2024-01-01",
                "dateTo": date_to or "2024-12-31",
                "totalOrders": 3,
                "avgPrice": 3050.0,
                "currency": "INR",
                "orders": [
                    {"poNumber": "4500001234", "quantity": 500, "netPrice": 3000.0, "postingDate": "2024-03-15"},
                    {"poNumber": "4500001456", "quantity": 600, "netPrice": 3100.0, "postingDate": "2024-07-10"},
                    {"poNumber": "4500001789", "quantity": 400, "netPrice": 3050.0, "postingDate": "2024-11-20"},
                ],
            })

        client = s4 or S4Client()
        filter_parts = [f"Material eq '{material_number}'", f"Plant eq '{plant}'"]
        if date_from:
            filter_parts.append(f"DocumentDate ge datetime'{date_from}T00:00:00'")
        if date_to:
            filter_parts.append(f"DocumentDate le datetime'{date_to}T23:59:59'")

        params = {
            "$filter": " and ".join(filter_parts),
            "$select": (
                "PurchaseOrder,PurchaseOrderItem,Plant,Material,PurchaseOrderItemText,"
                "OrderQuantity,PurchaseOrderQuantityUnit,NetPriceAmount,"
                "GoodsReceiptIsExpected,InvoiceIsExpected"
            ),
            "$top": MAX_PAGE_SIZE,
        }
        _ensure_format(params)
        result = await client.get(f"{PO_ROOT}/A_PurchaseOrderItem", params=params)
        if result.get("error"):
            return json.dumps({"error": result.get("message"), "materialNumber": material_number})

        items = result.get("results", [])
        orders = [
            {
                "poNumber": i.get("PurchaseOrder", ""),
                "poItem": i.get("PurchaseOrderItem", ""),
                "quantity": i.get("OrderQuantity", 0),
                "netPrice": i.get("NetPriceAmount", 0),
            }
            for i in items
        ]
        prices = [float(o["netPrice"]) for o in orders if o["netPrice"]]
        avg = round(sum(prices) / len(prices), 2) if prices else 0.0
        return json.dumps({
            "materialNumber": material_number,
            "plant": plant,
            "dateFrom": date_from or "",
            "dateTo": date_to or "",
            "totalOrders": len(orders),
            "avgPrice": avg,
            "orders": orders,
        })

    except Exception as e:
        return json.dumps({"error": str(e), "materialNumber": material_number})


async def get_material_valuation(
    material_number: str,
    plant: str,
    valuation_area: str | None = None,
    s4: S4Client | None = None,
) -> str:
    """
    Retrieve material valuation: standard price, moving average price, currency, price control.

    Uses API_PRODUCT_SRV/A_ProductValuation — confirmed working on CIN_100.
    Falls back to API_PRODUCT_SRV/A_ProductPlant for procurement type if valuation empty.
    """
    try:
        if os.environ.get("IBD_TESTING") == "1":
            prices = {"ENG": 45000.0, "TRANS": 38000.0, "BRAKE": 3200.0}
            base_price = next((v for k, v in prices.items() if k in material_number), 5000.0)
            return json.dumps({
                "materialNumber": material_number,
                "plant": plant,
                "valuationArea": valuation_area or plant,
                "movingAveragePrice": base_price,
                "standardPrice": base_price * 0.98,
                "priceControl": "V",
                "currency": "INR",
                "valuationClass": "3000",
            })

        client = s4 or S4Client()
        va = valuation_area or plant

        # PRIMARY: API_PRODUCT_SRV/A_ProductValuation — CONFIRMED working on CIN_100
        params = {
            "$filter": f"Product eq '{material_number}' and ValuationArea eq '{va}'",
            "$top": "1",
            "$format": "json",
        }
        result = await client.get(f"{PRODUCT_ROOT}/A_ProductValuation", params=params)
        logger.info(f"[valuation] {material_number}/{va} A_ProductValuation error={result.get('error')} sample={str(result)[:200]}")

        items = result.get("results", [])

        # FALLBACK: API_PRODUCT_SRV/A_ProductPlant for procurement type only
        if not items:
            logger.warning(f"[valuation] A_ProductValuation returned no items for {material_number}/{plant}, trying A_ProductPlant")
            params2 = {
                "$filter": f"Product eq '{material_number}' and Plant eq '{plant}'",
                "$select": "Product,Plant,ProcurementType,MRPType",
                "$top": "1",
                "$format": "json",
            }
            r2 = await client.get(f"{PRODUCT_ROOT}/A_ProductPlant", params=params2)
            pp_items = r2.get("results", [])
            if pp_items:
                pi = pp_items[0]
                return json.dumps({
                    "materialNumber": material_number, "plant": plant, "valuationArea": va,
                    "procurementType": pi.get("ProcurementType", ""),
                    "mrpType": pi.get("MRPType", ""),
                    "standardPrice": 0.0, "movingAveragePrice": 0.0,
                    "effectivePrice": 0.0, "currency": "", "priceControl": "",
                    "note": "Price data not in valuation API; procurement type from ProductPlant",
                })
            err_msg = result.get("message", "No valuation data found")
            return json.dumps({"error": err_msg, "materialNumber": material_number, "plant": plant})

        item = items[0]
        logger.info(f"[valuation] item keys: {list(item.keys())[:15]}")

        # Field names confirmed from CIN_100 A_ProductValuation
        pc  = item.get("PriceDeterminationControl") or item.get("PriceControlIndicator") or ""
        std = float(item.get("StandardPrice") or 0)
        mav = float(item.get("MovingAveragePrice") or 0)
        use_std = pc in ("S", "2")
        effective = std if use_std else (mav if mav else std)
        currency  = item.get("Currency") or item.get("CurrencyCode") or ""
        val_class = item.get("ValuationClass") or ""
        val_cat   = item.get("ValuationCategory") or ""
        price_unit = float(item.get("PriceUnitQty") or 1)
        old_std   = float(item.get("OldStandardPrice") or 0)
        last_chg  = item.get("LastStandardPriceChangeDate") or item.get("LastChangeDate") or ""
        total_stock = float(item.get("TotalStock") or item.get("TotalValuedStockQty") or 0)
        total_val   = float(item.get("TotalValuedStock") or item.get("TotalStockValue") or 0)
        pc_label = {"S": "Standard Price (S)", "2": "Standard Price (S)",
                    "V": "Moving Average (V)", "3": "Moving Average (V)"}.get(pc, pc or "Unknown")

        return json.dumps({
            "materialNumber": material_number, "plant": plant, "valuationArea": va,
            "priceControl": pc, "priceControlLabel": pc_label,
            "valuationClass": val_class, "valuationCategory": val_cat,
            "priceUnit": price_unit, "currency": currency,
            "standardPrice": std, "movingAveragePrice": mav, "effectivePrice": effective,
            "oldStandardPrice": old_std, "lastPriceChangeDate": last_chg,
            "totalStock": total_stock, "totalStockValue": total_val,
        })

    except Exception as e:
        return json.dumps({"error": str(e), "materialNumber": material_number})


async def trigger_procurement_review_workflow(
    analysis_id: str,
    priority: str = "Medium",
    comments: str | None = None,
) -> str:
    """Trigger procurement review workflow via the CAP WorkflowTriggerService."""
    try:
        result = await _call_cap(
            "/api/triggerProcurementReview",
            method="POST",
            body={"analysisId": analysis_id, "priority": priority, "comments": comments or ""},
        )
        logger.info(f"[M2.achieved: procurement workflow triggered for {analysis_id}]")
        return json.dumps(result)
    except httpx.HTTPStatusError as e:
        error_msg = f"HTTP {e.response.status_code}: {e.response.text[:200]}"
        logger.error(f"[M2.missed: procurement workflow trigger failed for {analysis_id}, reason={error_msg}]")
        return json.dumps({"error": error_msg, "analysisId": analysis_id})
    except Exception as e:
        logger.error(f"[M2.missed: procurement workflow trigger failed for {analysis_id}, reason={e}]")
        return json.dumps({"error": str(e), "analysisId": analysis_id})


async def trigger_costing_review_workflow(
    analysis_id: str,
    cost_center: str | None = None,
    comments: str | None = None,
) -> str:
    """Trigger costing review workflow via the CAP WorkflowTriggerService."""
    try:
        result = await _call_cap(
            "/api/triggerCostingReview",
            method="POST",
            body={"analysisId": analysis_id, "costCenter": cost_center or "", "comments": comments or ""},
        )
        logger.info(f"[M2.achieved: costing workflow triggered for {analysis_id}]")
        return json.dumps(result)
    except httpx.HTTPStatusError as e:
        error_msg = f"HTTP {e.response.status_code}: {e.response.text[:200]}"
        logger.error(f"[M2.missed: costing workflow trigger failed for {analysis_id}, reason={error_msg}]")
        return json.dumps({"error": error_msg, "analysisId": analysis_id})
    except Exception as e:
        logger.error(f"[M2.missed: costing workflow trigger failed for {analysis_id}, reason={e}]")
        return json.dumps({"error": str(e), "analysisId": analysis_id})


# ---------------------------------------------------------------------------
# Tool registry
# ---------------------------------------------------------------------------

def get_bom_tools(s4: S4Client | None = None) -> list[StructuredTool]:
    """Return all 12 BOM cost optimization tools as LangChain StructuredTool instances."""
    _client = s4 or S4Client()

    async def _get_bom_headers(material_number, plant=None, bom_usage=None, bom_category="M"):
        return await get_bom_headers(material_number, plant, bom_usage, bom_category, s4=_client)

    async def _get_material_by_bom_number(bom_number, plant=None):
        return await get_material_by_bom_number(bom_number, plant, s4=_client)

    async def _get_bom_explosion(material_number, plant, bom_usage="1", explosion_type="multi"):
        return await get_bom_explosion(material_number, plant, bom_usage, explosion_type, s4=_client)

    async def _list_material_plants(material_number):
        return await list_material_plants(material_number, s4=_client)

    async def _get_material_count(material_type=None):
        return await get_material_count(material_type, s4=_client)

    async def _get_tcurr_fx_rate(from_currency, to_currency, rate_type="M", date=None):
        return await get_tcurr_fx_rate(from_currency, to_currency, rate_type, date, s4=_client)

    async def _get_bom_cross_plant(vehicle_material, plant1, plant2, usage=None, alternative=None):
        return await get_bom_cross_plant(vehicle_material, plant1, plant2, usage, alternative, s4=_client)

    async def _get_material_procurement_type(material_number, plant):
        return await get_material_procurement_type(material_number, plant, s4=_client)

    async def _get_purchase_info_records(material_number, plant, purchasing_org=None):
        return await get_purchase_info_records(material_number, plant, purchasing_org, s4=_client)

    async def _get_purchase_order_history(material_number, plant, date_from=None, date_to=None):
        return await get_purchase_order_history(material_number, plant, date_from, date_to, s4=_client)

    async def _get_material_valuation(material_number, plant, valuation_area=None):
        return await get_material_valuation(material_number, plant, valuation_area, s4=_client)

    return [
        StructuredTool(
            name="get_material_by_bom_number",
            description=(
                "REVERSE BOM lookup: given a BOM NUMBER, find which MATERIAL it belongs to. "
                "Use this when user asks 'which material has BOM 00000052?', "
                "'material against BOM 00000023', 'what material is BOM number X for?', "
                "'elaborate BOM number 00000053'. "
                "This is DIFFERENT from get_bom_headers which goes Material → BOM. "
                "This tool goes BOM Number → Material (the reverse direction). "
                "ALWAYS use this tool when the user gives you a BOM NUMBER and asks for the MATERIAL."
            ),
            args_schema=GetMaterialByBomNumberInput,
            coroutine=_get_material_by_bom_number,
            handle_tool_error=True,
        ),
        StructuredTool(
            name="get_bom_headers",
            description=(
                "Fetch BOM numbers (Bill of Material numbers) for a material from SAP CIN_100. "
                "Call this when user asks 'what is the BOM number', 'BOM numbers for material X', "
                "'which BOM is assigned to this material', 'BOM header for plant X'. "
                "Returns BOM number, category (M=Material), variant, plant, and usage type. "
                "If plant is omitted, returns BOMs across ALL plants where the material has a BOM. "
                "This is the PRIMARY tool for BOM number queries."
            ),
            args_schema=GetBomHeadersInput,
            coroutine=_get_bom_headers,
            handle_tool_error=True,
        ),
        StructuredTool(
            name="get_bom_explosion",
            description=(
                "Explode a BOM (multi-level by default) to get all components/sub-components. "
                "Use when user asks 'explode BOM', 'what components does X contain', "
                "'multi-level BOM explosion', 'BOM structure', 'CS12 equivalent'. "
                "Returns all components with quantity, unit, and scrap percentage."
            ),
            args_schema=GetBomExplosionInput,
            coroutine=_get_bom_explosion,
            handle_tool_error=True,
        ),
        StructuredTool(
            name="list_material_plants",
            description=(
                "ALWAYS call this FIRST when a user asks about a material without specifying plants. "
                "Discovers ALL plants where the material is maintained in SAP CIN_100. "
                "Returns real plant codes (numeric like 1010, 1710, 1720) — use these for all follow-up calls. "
                "NEVER guess plant codes. NEVER use MANE or GURG — those are not valid SAP plant codes in this system."
            ),
            args_schema=ListMaterialPlantsInput,
            coroutine=_list_material_plants,
            handle_tool_error=True,
        ),
        StructuredTool(
            name="get_material_count",
            description=(
                "Get the total count of materials in SAP S/4HANA system CIN_100. "
                "Use when user asks 'how many materials are there', 'total material count', etc. "
                "Optionally filter by material type (ROH=Raw, HALB=Semi-finished, FERT=Finished)."
            ),
            args_schema=GetMaterialCountInput,
            coroutine=_get_material_count,
            handle_tool_error=True,
        ),
        StructuredTool(
            name="get_tcurr_fx_rate",
            description=(
                "Fetch live FX exchange rate from SAP TCURR table in CIN_100 — the AUTHORITATIVE source. "
                "Always call this BEFORE doing any currency conversion. "
                "Automatically tries direct rate, then inverse, then indirect (via USD), then open.er-api.com fallback. "
                "Use this instead of hardcoded rates. Example: get_tcurr_fx_rate('EUR', 'INR') for EUR→INR."
            ),
            args_schema=GetTcurrFxRateInput,
            coroutine=_get_tcurr_fx_rate,
            handle_tool_error=True,
        ),
        StructuredTool(
            name="get_bom_cross_plant",
            description=(
                "Retrieve and compare BOM component costs for a vehicle material across two manufacturing plants. "
                "Returns cost per component for each plant, absolute and percentage variance, and total impact INR."
            ),
            args_schema=GetBomCrossPlantInput,
            coroutine=_get_bom_cross_plant,
            handle_tool_error=True,
        ),
        StructuredTool(
            name="get_material_procurement_type",
            description=(
                "Retrieve the procurement type for a material at a plant from S/4HANA material master. "
                "E=In-house production, F=External procurement, X=Both. Used for Make/Buy classification."
            ),
            args_schema=GetMaterialProcurementTypeInput,
            coroutine=_get_material_procurement_type,
            handle_tool_error=True,
        ),
        StructuredTool(
            name="get_purchase_info_records",
            description=(
                "Retrieve purchase info records for a material, showing vendor prices and supplier count. "
                "Used to detect single-supplier dependency (triggers Strategic Buy classification)."
            ),
            args_schema=GetPurchaseInfoRecordsInput,
            coroutine=_get_purchase_info_records,
            handle_tool_error=True,
        ),
        StructuredTool(
            name="get_purchase_order_history",
            description=(
                "Retrieve purchase order history for a material at a plant. "
                "Shows historical quantities, prices, and posting dates for trend analysis."
            ),
            args_schema=GetPurchaseOrderHistoryInput,
            coroutine=_get_purchase_order_history,
            handle_tool_error=True,
        ),
        StructuredTool(
            name="get_material_valuation",
            description=(
                "Retrieve material valuation data (moving average price, standard price) for a material at a plant. "
                "Used to validate BOM component costs against current valuation."
            ),
            args_schema=GetMaterialValuationInput,
            coroutine=_get_material_valuation,
            handle_tool_error=True,
        ),
        StructuredTool(
            name="trigger_procurement_review_workflow",
            description=(
                "Trigger a procurement review workflow for a saved BOM analysis. "
                "Sends the analysis to the procurement team via the n8n workflow. "
                "Requires a valid analysis_id from the CAP service (BomAnalysis.ID)."
            ),
            args_schema=TriggerProcurementReviewInput,
            coroutine=trigger_procurement_review_workflow,
            handle_tool_error=True,
        ),
        StructuredTool(
            name="trigger_costing_review_workflow",
            description=(
                "Trigger a costing review workflow for a saved BOM analysis. "
                "Sends the analysis to the costing team via the n8n workflow. "
                "Requires a valid analysis_id from the CAP service (BomAnalysis.ID)."
            ),
            args_schema=TriggerCostingReviewInput,
            coroutine=trigger_costing_review_workflow,
            handle_tool_error=True,
        ),
    ]
