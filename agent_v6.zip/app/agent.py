"""
BOMA — BOM Analysis Agent (v5.0.0)
Dual-mode: Joule Studio (JOULE_RUNTIME=1) or Cloud Foundry AI Core (JOULE_RUNTIME=0)
"""
from __future__ import annotations

import logging
import os
import time
import urllib.request
import json as _json
from dataclasses import dataclass
from typing import AsyncGenerator, Literal, Sequence

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.tools import BaseTool
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.prebuilt import create_react_agent

logger = logging.getLogger(__name__)

_JOULE       = os.environ.get("JOULE_RUNTIME", "0") == "1"
_IBD_TESTING = os.environ.get("IBD_TESTING",   "0") == "1"
THREAD_TTL_SECONDS = 3600

# ─────────────────────────────────────────────────────────────────────────────
# Live FX rates — fetched from open.er-api.com (free, no key needed)
# Cached 30 min so every agent response uses fresh market rates
# ─────────────────────────────────────────────────────────────────────────────
_fx_cache: dict = {}
_fx_cache_time: float = 0.0
_FX_TTL = 1800


def get_live_fx_rates() -> dict:
    global _fx_cache, _fx_cache_time
    now = time.monotonic()
    if _fx_cache and (now - _fx_cache_time) < _FX_TTL:
        return _fx_cache
    try:
        url = "https://open.er-api.com/v6/latest/USD"
        r = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(r, timeout=6) as resp:
            data = _json.loads(resp.read())
        rates = data.get("rates", {})
        if not rates:
            raise ValueError("empty rates")
        usd_inr = float(rates.get("INR", 96.35))
        usd_eur = float(rates.get("EUR", 0.873))
        usd_gbp = float(rates.get("GBP", 0.741))
        usd_jpy = float(rates.get("JPY", 149.5))
        usd_chf = float(rates.get("CHF", 0.893))
        _fx_cache = {
            "USD_INR": round(usd_inr, 4),
            "EUR_INR": round(usd_inr / usd_eur, 4),
            "EUR_USD": round(1 / usd_eur, 4),
            "GBP_INR": round(usd_inr / usd_gbp, 4),
            "GBP_USD": round(1 / usd_gbp, 4),
            "JPY_INR": round(usd_inr / usd_jpy, 6),
            "CHF_INR": round(usd_inr / usd_chf, 4),
            "CHF_USD": round(1 / usd_chf, 4),
            "INR_USD": round(1 / usd_inr, 8),
            "INR_EUR": round(usd_eur / usd_inr, 8),
            "_source": "open.er-api.com",
            "_as_of": data.get("time_last_update_utc", "live"),
        }
        _fx_cache_time = now
        logger.info("FX refreshed: 1 USD = %.4f INR", usd_inr)
    except Exception as exc:
        logger.warning("FX fetch failed: %s — using fallback", exc)
        if not _fx_cache:
            _fx_cache = {
                "USD_INR": 96.35, "EUR_INR": 110.37, "EUR_USD": 1.145,
                "GBP_INR": 130.0, "GBP_USD": 1.35, "JPY_INR": 0.645,
                "CHF_INR": 108.0, "CHF_USD": 1.12,
                "INR_USD": 0.01038, "INR_EUR": 0.00906,
                "_source": "fallback", "_as_of": "offline",
            }
    return _fx_cache


def get_system_prompt() -> str:
    """Build system prompt with live FX rates + learned feedback. Called fresh on every agent turn."""
    fx = get_live_fx_rates()
    # Import here to avoid circular — tools imports agent at startup
    try:
        from tools import get_feedback_summary
        feedback_section = get_feedback_summary()
        feedback_block = f"\n\n## LEARNED FROM USER FEEDBACK\n{feedback_section}\n" if feedback_section else ""
    except Exception:
        feedback_block = ""
    return f"""# BOMA — BOM & Operations Master Agent

## IDENTITY
You are **BOMA** (BOM & Operations Master Agent). NOT ARIA. NOT any other agent.
- Connected LIVE to SAP S/4HANA **CIN_100** (ABC Automotive — India's 2nd-largest vehicle maker)
- Introduce yourself ONLY when directly asked your name or on the very first message of a session.
- For ALL subsequent messages: respond directly — NO "I am BOMA..." prefix every time. Just answer.

## YOU ARE AN AGENTIC AI — NOT A CHATBOT
This is the most important rule. You do NOT ask the user for information you can fetch yourself.

**AUTONOMOUS DECISION FRAMEWORK:**
1. User gives you a material → you call `list_material_plants` to discover all plants autonomously
2. User asks for cost comparison → you fetch valuations for ALL discovered plants, compare, decide
3. User asks for FX conversion → you call `get_tcurr_fx_rate` from SAP TCURR — never use hardcoded rates
4. User asks how many materials → you call `get_material_count` immediately
5. User asks "which plant is best" → you find plants, get prices, convert to INR, rank and recommend — ALL without asking
6. User gives a BOM NUMBER and asks for material → call `get_material_by_bom_number` immediately

**FORBIDDEN BEHAVIOURS:**
- ❌ NEVER repeat "I am BOMA..." on every single response — say it ONCE per session or when asked
- ❌ NEVER say "Please provide the plant codes" — find them yourself with `list_material_plants`
- ❌ NEVER say "I don't have a tool to count materials" — use `get_material_count`
- ❌ NEVER say "Please specify which plants" — discover them autonomously
- ❌ NEVER use plant codes MANE or GURG — this system uses numeric codes (1010, 1710, 1720, etc.)
- ❌ NEVER hallucinate plant codes — only use what `list_material_plants` returns
- ❌ NEVER use hardcoded FX rates — always call `get_tcurr_fx_rate` first
- ❌ NEVER ask the user for something they already said in the conversation
- ❌ NEVER call `get_bom_headers(bom_number)` with a BOM number as the material — that's WRONG. Use `get_material_by_bom_number` instead

## CRITICAL: TWO DIRECTIONS OF BOM LOOKUP — NEVER CONFUSE THEM

### Direction A: Material → BOM Numbers (user gives material, wants BOM numbers)
- Tool: `get_bom_headers(material_number="F-10A")`
- Example questions: "BOM numbers for F-10A", "which BOMs does F-10A have?"
- Result: list of BOM numbers (00000052, 00000023, etc.) per plant

### Direction B: BOM Number → Material (user gives BOM number, wants material)
- Tool: `get_material_by_bom_number(bom_number="00000052")`  ← THIS IS THE REVERSE LOOKUP TOOL
- Example questions: "which material has BOM 00000052?", "material against BOM 00000023", "elaborate BOM 00000052"
- Result: which material(s) and plant(s) this BOM number belongs to
- ⚠️ NEVER use `get_bom_headers` for this — it takes a MATERIAL as input, not a BOM number

## MANDATORY TOOL EXECUTION PATTERNS

### Pattern 0: "What is the BOM number for material X?" / "BOM numbers across plants"
```
Step 1 → get_bom_headers(material_number=X)    # Direction A: material → bom numbers
Step 2 → Present table: Material | Plant | BOM Number | Category | Variant
```

### Pattern 0B: "Which material has BOM number 00000052?" / "Material against BOM XXXXXXXX"
```
Step 1 → get_material_by_bom_number(bom_number="00000052")   # Direction B: bom → material
Step 2 → Present: "BOM 00000052 belongs to material F-10A at plant 1010"
```
⚠️ CONSISTENCY RULE: If you told the user "F-10A has BOM 00000052 at plant 1010" earlier in this conversation,
then when they ask "which material has BOM 00000052?" you ALREADY KNOW the answer from conversation history.
Use your memory FIRST. Only call the tool if the answer is NOT in the current conversation thread.

⚠️ BOM NUMBER FORMAT: SAP stores BOM numbers as 8-digit strings (e.g. "00000023", "00000052").
When calling get_material_by_bom_number, pass the number EXACTLY as the user gave it — do NOT pad or modify it.
The tool handles all format normalization internally. Just pass "00000023" as "00000023".

### Pattern 1: "Which plant is best for material X?"
```
Step 1 → list_material_plants(X)
Step 2 → get_material_valuation(X, plant) for each plant
Step 3 → get_tcurr_fx_rate(currency, INR) for each currency
Step 4 → Convert to INR, rank, recommend cheapest, classify Make/Buy/Strategic Buy
```

### Pattern 2: "How many materials?"
```
Step 1 → get_material_count() immediately
```

### Pattern 3: BOM components for a material
```
Step 1 → get_bom_headers(material_number=X) to get BOM number + plant
Step 2 → get_bom_explosion(material_number=X, plant=plant_from_step1)
Step 3 → Present component table
```

### Pattern 4: FX conversion
```
Step 1 → get_tcurr_fx_rate(from, to) — never use hardcoded rates
```

## FX RATE RULES
- **PRIMARY**: Always call `get_tcurr_fx_rate` — SAP TCURR table is authoritative
- **FALLBACK** (only if tool fails): {fx['_source']} rates as of {fx['_as_of']}:
  - 1 USD = {fx['USD_INR']} INR | 1 EUR = {fx['EUR_INR']} INR | 1 GBP = {fx['GBP_INR']} INR
- ❌ FORBIDDEN: USD→INR=83.3, EUR→INR=89.9

## MAKE / BUY / STRATEGIC BUY CLASSIFICATION
- 🏭 **MAKE**: Procurement=E OR variance < 5%
- 🛒 **BUY**: Variance ≥ 5%, multiple suppliers
- ⚠️ **STRATEGIC BUY**: Variance ≥ 20% + single supplier

## CONVERSATION MEMORY RULES
You have full memory of this conversation thread. USE IT:
- If material plants were already discovered → use them, don't call list_material_plants again
- If BOM numbers were already fetched → use them from memory
- If BOM number → material mapping was already established → answer from memory immediately
- If user references something said earlier → use it without asking again
- CONSISTENCY: Never contradict yourself. If you said "BOM 00000023 = F-10A at plant 1710" — stick to that.

## HONEST FAILURE PROTOCOL
If a tool returns no data: explain what happened clearly. 
NEVER hallucinate BOM numbers or materials. Only state what the tool actually returned.

## OUTPUT FORMAT
- Use markdown tables for all structured data
- NO "I am BOMA..." prefix on every message — answer directly
- T-codes at the end when relevant: 📋 MM03, CS03, CK11N, etc.

## CAPABILITIES
BOM: CS03 · CS11 · CS12 · CS15 · CS20 | Cost: CK11N · CK40N · MR21 | 
Procurement: ME11 · ME13 · ME2M · ME57 | Valuation: MM03 · MB52 · MIRO |
Production: PP01 · CA01 · CO01 | FI/CO: FB60 · F110 · KSB1 · KE30 |
Quality: QA01 · QM11 · QA32 | All SAP modules: MM · SD · FI · CO · PP · WM · QM · PM · PS{feedback_block}"""


# ─────────────────────────────────────────────────────────────────────────────
# Decorator shim (Joule vs CF)
# ─────────────────────────────────────────────────────────────────────────────
try:
    from sap_cloud_sdk.agent_decorators import agent_model, agent_config, prompt_section  # type: ignore
except ImportError:
    def _noop(*_a, **_k):
        def _w(fn): return fn
        return _w
    agent_model = agent_config = prompt_section = _noop  # type: ignore

# ─────────────────────────────────────────────────────────────────────────────
# S4 client
# ─────────────────────────────────────────────────────────────────────────────
if not _JOULE and not _IBD_TESTING:
    try:
        from s4hana_client import Client as S4Client  # type: ignore
    except ImportError:
        S4Client = None  # type: ignore
else:
    S4Client = None  # type: ignore


def get_model_name() -> str:
    return os.environ.get("AGENT_LLM_MODEL", "gpt-4o")


# ─────────────────────────────────────────────────────────────────────────────
# AgentResponse
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class AgentResponse:
    status: Literal["input_required", "completed", "error"]
    message: str


# ─────────────────────────────────────────────────────────────────────────────
# SampleAgent
# ─────────────────────────────────────────────────────────────────────────────
class SampleAgent:
    SUPPORTED_CONTENT_TYPES = ["text", "text/plain"]

    def __init__(self, s4_client=None):
        self._llm: BaseChatModel | None = None
        self._checkpointer = InMemorySaver()
        self._graph = None          # built once, reused across all turns
        self._last_active: dict[str, float] = {}
        self._thread_message_count: dict[str, int] = {}  # track turn number per thread
        self._s4_client = s4_client if s4_client is not None else (
            S4Client() if S4Client is not None else None
        )

    @property
    def s4_client(self):
        return self._s4_client

    # ── LLM (lazy, built once) ────────────────────────────────────────────────
    async def _get_llm(self) -> BaseChatModel | None:
        if self._llm is not None:
            return self._llm

        if _IBD_TESTING:
            try:
                from langchain_openai import ChatOpenAI  # type: ignore
                self._llm = ChatOpenAI(model="gpt-4o-mini", api_key="test-key", base_url="http://localhost:9999/")
                return self._llm
            except ImportError:
                pass
            try:
                from langchain_community.chat_models.fake import FakeMessagesListChatModel  # type: ignore
                from langchain_core.messages import AIMessage
                self._llm = FakeMessagesListChatModel(responses=[AIMessage(content="Mock response")])
                return self._llm
            except ImportError:
                pass
            return None

        if _JOULE:
            try:
                from langchain_litellm import ChatLiteLLM  # type: ignore
                self._llm = ChatLiteLLM(model="sap/anthropic--claude-4.5-sonnet", temperature=0.0)
            except ImportError as exc:
                logger.warning("Joule LLM unavailable: %s", exc)
            return self._llm

        try:
            from aicore import init_llm_from_destination  # type: ignore
            self._llm = await init_llm_from_destination(get_model_name(), temperature=0.0)
        except Exception as exc:
            logger.warning("init_llm_from_destination failed: %s", exc)
            try:
                from aicore import build_aicore_llm  # type: ignore
                self._llm = build_aicore_llm(
                    model=os.environ.get("AICORE_MODEL", get_model_name()), temperature=0.0
                )
            except Exception as exc2:
                logger.warning("build_aicore_llm also failed: %s", exc2)
        return self._llm

    # ── Graph (built once per agent instance, reused for all threads) ─────────
    async def _get_graph(self, tools: Sequence[BaseTool]):
        """
        Build graph once and cache it. The pre_model_hook fetches a fresh
        system prompt (with live FX) before every LLM call, so rates are always current.
        """
        if self._graph is not None:
            return self._graph

        llm = await self._get_llm()
        if llm is None:
            return None

        tool_list = list(tools) if tools else []

        def _pre_model_hook(state: dict) -> dict:
            """
            Fires immediately before every LLM call.
            Replaces/prepends SystemMessage with fresh BOMA identity + live FX.
            This cannot be overridden by base-model fine-tuning.
            """
            fresh_prompt = get_system_prompt()
            messages = list(state.get("messages", []))
            # Drop any existing SystemMessage at position 0
            if messages and isinstance(messages[0], SystemMessage):
                messages = messages[1:]
            return {"messages": [SystemMessage(content=fresh_prompt)] + messages}

        self._graph = create_react_agent(
            llm,
            tools=tool_list,
            pre_model_hook=_pre_model_hook,
            checkpointer=self._checkpointer,
        )
        logger.info("BOMA graph built with %d tools", len(tool_list))
        return self._graph

    # ── Thread TTL cleanup ────────────────────────────────────────────────────
    def _touch(self, thread_id: str) -> None:
        now = time.monotonic()
        expired = [tid for tid, ts in list(self._last_active.items()) if now - ts > THREAD_TTL_SECONDS]
        for tid in expired:
            try:
                self._checkpointer.delete_thread(tid)
            except Exception:
                pass
            del self._last_active[tid]
            self._thread_message_count.pop(tid, None)
            logger.info("Evicted thread: %s", tid)
        self._last_active[thread_id] = now

    def _wrap_query(self, query: str, is_first_message: bool = False) -> str:
        """
        Wrap every user query with BOMA agentic rules.
        Injected into the HUMAN turn — takes effect even when AI Core overrides system message.
        """
        import re as _re
        fx = get_live_fx_rates()

        # Extract [SAP SCOPE] block if present (added by React UI)
        scope_block = ""
        clean_query = query
        scope_match = _re.search(r'\[SAP SCOPE\](.*?)\n', query, _re.DOTALL)
        if scope_match:
            scope_block = scope_match.group(1).strip()
            clean_query = query[scope_match.end():].strip()

        # Build explicit plant/material instruction from UI scope
        scope_instruction = ""
        if scope_block:
            mat_match = _re.search(r'Materials in scope:\s*([^\|]+)', scope_block)
            plt_match = _re.search(r'Plants in scope:\s*([^\|]+)', scope_block)
            mats = mat_match.group(1).strip() if mat_match else ""
            plts = plt_match.group(1).strip() if plt_match else ""
            if plts:
                scope_instruction = f"\n⚠️ USER-SPECIFIED PLANTS: {plts} — use ONLY these. Never invent plant codes."
            if mats:
                scope_instruction += f"\n⚠️ USER-SPECIFIED MATERIALS: {mats}"

        # Extract plants mentioned directly in the question
        plant_codes = _re.findall(r'\b(1\d{3}|2\d{3}|3\d{3})\b', clean_query)
        mentioned_plants = f"\nPlants mentioned in question: {', '.join(set(plant_codes))}" if plant_codes else ""

        # Detect if user is asking for reverse BOM lookup (BOM number → material)
        # Match: leading zeros followed by digits (BOM number patterns like 00000023, 00000052, 105, etc.)
        bom_num_match = _re.search(r'\b(0*\d{5,10})\b', clean_query)
        reverse_hint = ""
        reverse_keywords = [
            "material", "which", "what", "against", "associated", "belong",
            "for bom", "of bom", "elaborate", "tell me about bom", "bom number"
        ]
        if bom_num_match and any(kw in clean_query.lower() for kw in reverse_keywords):
            bom_candidate = bom_num_match.group(1)
            # Don't trigger if the "number" looks like a material (e.g. "F-10A plant 1010")
            if not _re.search(r'[A-Za-z]', bom_candidate):
                reverse_hint = (
                    f"\n🔁 REVERSE BOM LOOKUP DETECTED: User gave BOM number '{bom_candidate}' and wants the MATERIAL. "
                    f"MANDATORY: Call get_material_by_bom_number(bom_number='{bom_candidate}') RIGHT NOW. "
                    f"Pass the number EXACTLY as '{bom_candidate}' — the tool handles padding internally. "
                    f"Do NOT call get_bom_headers. Do NOT say 'invalid'. Just call the tool."
                )

        # Only show intro instruction on first message
        identity_rule = (
            "RULE 1 — INTRO: This is the first message. Introduce yourself briefly as BOMA."
            if is_first_message else
            "RULE 1 — NO INTRO: Do NOT start with 'I am BOMA...'. Answer directly and concisely."
        )

        return f"""[BOMA RULES]
{identity_rule}
RULE 2 — FX: Call get_tcurr_fx_rate first. Fallback: 1 USD={fx['USD_INR']} INR, 1 EUR={fx['EUR_INR']} INR
RULE 3 — PLANTS: NEVER use MANE/GURG. No plants given? Call list_material_plants to discover them.
RULE 4 — COUNT: "how many materials?" → call get_material_count immediately
RULE 5 — NO ASKING: Fetch what you need. Never ask for info you can get from a tool.
RULE 6 — MEMORY: Use conversation history. If you already fetched BOM numbers or plants — reuse them.
RULE 7 — REVERSE BOM: User gives BOM number and asks for material? Call get_material_by_bom_number.{mentioned_plants}{scope_instruction}{reverse_hint}
[END RULES]

USER: {clean_query}"""

    # ── stream ────────────────────────────────────────────────────────────────
    async def stream(
        self,
        query: str,
        context_id: str,
        tools: Sequence[BaseTool] | None = None,
    ) -> AsyncGenerator[dict, None]:
        self._touch(context_id)
        yield {"is_task_complete": False, "require_user_input": False, "content": "Analysing..."}

        try:
            graph = await self._get_graph(tools or [])
            if graph is None:
                yield {"is_task_complete": True, "require_user_input": False,
                       "content": "LLM not configured. Check AI Core / Joule settings."}
                return

            config = {"configurable": {"thread_id": context_id}}
            # Track message count per thread to avoid repeating intro
            msg_count = self._thread_message_count.get(context_id, 0)
            is_first = msg_count == 0
            self._thread_message_count[context_id] = msg_count + 1
            wrapped = self._wrap_query(query, is_first_message=is_first)
            result = await graph.ainvoke({"messages": [HumanMessage(content=wrapped)]}, config)
            self._touch(context_id)

            yield {"is_task_complete": True, "require_user_input": False,
                   "content": result["messages"][-1].content}

        except Exception as e:
            logger.exception("BOMA stream() error")
            yield {"is_task_complete": True, "require_user_input": False,
                   "content": f"Error processing request: {e}. Please try again."}

    # ── invoke (convenience wrapper) ──────────────────────────────────────────
    async def invoke(
        self,
        query: str,
        context_id: str,
        tools: Sequence[BaseTool] | None = None,
    ) -> AgentResponse:
        last: dict = {}
        async for chunk in self.stream(query, context_id, tools=tools):
            last = chunk
        if last.get("is_task_complete"):
            return AgentResponse(status="completed", message=last["content"])
        if last.get("require_user_input"):
            return AgentResponse(status="input_required", message=last["content"])
        return AgentResponse(status="error", message=last.get("content", "Unknown error"))
