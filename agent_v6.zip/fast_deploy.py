"""Fast CF deploy for bom-cost-optimization-agent using passcode SSO"""
import os, sys, json, time, zipfile, tempfile, urllib.request, urllib.error, urllib.parse, base64, ssl

API   = "https://api.cf.us10.hana.ondemand.com"
UAA   = "https://uaa.cf.us10.hana.ondemand.com"
APP   = "bom-cost-optimization-agent"
ORG   = "gdh-prj-vector-hackathon-apac-dev4-s2ydk575"
SPACE = "Dev"
SRC   = os.path.dirname(os.path.abspath(__file__))

passcode = sys.argv[1] if len(sys.argv) > 1 else ""
if not passcode:
    print("Usage: python3 fast_deploy.py <PASSCODE>"); sys.exit(1)

ctx = ssl._create_unverified_context()

def http(method, url, data=None, headers=None, raw_body=None):
    h = {"Accept": "application/json"}
    if headers: h.update(headers)
    if data is not None:
        body = json.dumps(data).encode()
        h["Content-Type"] = "application/json"
    elif raw_body is not None:
        body = raw_body
    else:
        body = None
    rq = urllib.request.Request(url, data=body, headers=h, method=method)
    try:
        with urllib.request.urlopen(rq, context=ctx, timeout=120) as r:
            raw = r.read()
            return (json.loads(raw) if raw else {}), r.status
    except urllib.error.HTTPError as e:
        raw = e.read()
        try: return json.loads(raw), e.code
        except: return {"_raw": raw.decode()[:500]}, e.code

def auth(method, url, token, data=None, raw_body=None, extra_headers=None):
    h = {"Authorization": f"Bearer {token}"}
    if extra_headers: h.update(extra_headers)
    return http(method, url, data=data, headers=h, raw_body=raw_body)

# 1. Get token
print("Getting token...")
creds64 = base64.b64encode(b"cf:").decode()
form = urllib.parse.urlencode({
    "grant_type": "password", "passcode": passcode, "response_type": "token",
}).encode()
rq = urllib.request.Request(f"{UAA}/oauth/token", data=form, headers={
    "Content-Type": "application/x-www-form-urlencoded",
    "Accept": "application/json",
    "Authorization": f"Basic {creds64}",
}, method="POST")
try:
    with urllib.request.urlopen(rq, context=ctx, timeout=30) as r:
        td = json.loads(r.read())
except urllib.error.HTTPError as e:
    print(f"Token failed ({e.code}): {e.read().decode()[:300]}"); sys.exit(1)

token = td.get("access_token", "")
if not token:
    print("No token:", td); sys.exit(1)
print(f"Got token (len={len(token)})")

# 2. Find GUIDs
orgs, _ = auth("GET", f"{API}/v3/organizations?names={urllib.parse.quote(ORG)}", token)
org_guid = (orgs.get("resources") or [{}])[0].get("guid", "")
spaces, _ = auth("GET", f"{API}/v3/spaces?names={urllib.parse.quote(SPACE)}&organization_guids={org_guid}", token)
space_guid = (spaces.get("resources") or [{}])[0].get("guid", "")
apps, _ = auth("GET", f"{API}/v3/apps?names={APP}&space_guids={space_guid}", token)
app_guid = (apps.get("resources") or [{}])[0].get("guid", "")
print(f"App GUID: {app_guid}")
if not app_guid:
    print("App not found — it may need to be created first"); sys.exit(1)

# 3. Zip app source (exclude __pycache__, *.pyc)
print("Zipping agent source...")
with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tf:
    zip_path = tf.name

include_roots = ["app"]
include_files = ["requirements.txt", "Procfile", "manifest.yml", "runtime.txt"]

with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
    for root_dir in include_roots:
        full_root = os.path.join(SRC, root_dir)
        for dirpath, dirs, files in os.walk(full_root):
            dirs[:] = [d for d in dirs if d != "__pycache__"]
            for f in files:
                if f.endswith(".pyc"): continue
                full = os.path.join(dirpath, f)
                arcname = os.path.relpath(full, SRC)
                zf.write(full, arcname)
    for f in include_files:
        full = os.path.join(SRC, f)
        if os.path.exists(full):
            zf.write(full, f)

print(f"Zip: {os.path.getsize(zip_path)/1024:.1f} KB")

# 4. Upload package
pkg, _ = auth("POST", f"{API}/v3/packages", token, data={
    "type": "bits",
    "relationships": {"app": {"data": {"guid": app_guid}}}
})
pkg_guid = pkg["guid"]
print(f"Package: {pkg_guid}")

with open(zip_path, "rb") as f: zip_data = f.read()
boundary = "CFboundary1234567890"
body = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"bits\"; filename=\"app.zip\"\r\nContent-Type: application/zip\r\n\r\n").encode() + zip_data + f"\r\n--{boundary}--\r\n".encode()
auth("POST", f"{API}/v3/packages/{pkg_guid}/upload", token, raw_body=body,
     extra_headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
print("Uploaded. Waiting for READY...")

for _ in range(30):
    time.sleep(3)
    p, _ = auth("GET", f"{API}/v3/packages/{pkg_guid}", token)
    state = p.get("state", "")
    print(f"  package: {state}")
    if state == "READY": break
    if state in ("FAILED", "EXPIRED"): print("Package failed:", p); sys.exit(1)

# 5. Build
build, _ = auth("POST", f"{API}/v3/builds", token, data={"package": {"guid": pkg_guid}})
build_guid = build["guid"]
print(f"Build: {build_guid}")
for _ in range(50):
    time.sleep(5)
    b, _ = auth("GET", f"{API}/v3/builds/{build_guid}", token)
    state = b.get("state", "")
    print(f"  build: {state}")
    if state == "STAGED": break
    if state == "FAILED": print("Build failed:", b.get("error", "")); sys.exit(1)
droplet_guid = b.get("droplet", {}).get("guid", "")
print(f"Droplet: {droplet_guid}")

# 6. Assign & restart
auth("PATCH", f"{API}/v3/apps/{app_guid}/relationships/current_droplet", token,
     data={"data": {"guid": droplet_guid}})
auth("POST", f"{API}/v3/apps/{app_guid}/actions/restart", token)
print("\n✅ Agent v3.0.0 deployed! https://bom-cost-optimization-agent.cfapps.us10.hana.ondemand.com/")
os.unlink(zip_path)
